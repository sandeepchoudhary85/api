<?php

/**
 *
 *Send Verification Email
 *
 */

 
 function sendverificationemail($email , $shuffled){
	
 $return_array = array();
  $data = array();
  $database = new medoo();
  $select_user = "SELECT `full_name`, `email`, `password` FROM `lv_users` WHERE `email`='$email' LIMIT 1";
  //print_r ($select_user);
  $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
  if(count($result) > 0) {
    $name = $result[0]['full_name'];
    $to = $result[0]['email'];
    $password = $result[0]['password'];
    $msg ='<!doctype html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>LectureVerb Forgot Password Mail</title>
      </head>
      <body style="margin:0px; padding:0px;overflow-y:auto;overflow-x:hidden;" >
        <span style="font-size:15px; color:black; padding:5px; margin:0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;">Hi '.$name.'</span>';
        $msg .= '<span style="font-size:15px; color:black; padding:5px; margin:10px 0 0 0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;"> Here is your verification code is.</span>';
        $msg .= '<span style="letter-spacing:10px; font-size:30px; color:black; padding:5px; margin:10px 0 0 0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;">'.$shuffled.'</span><br/></body></html>';
    $subject = "Hi ".$name.", Thanks for Registration Lecture Verb App.";
    if(mymail($to, $subject, $msg)){
	
			/// update user verification code  
		$updateuserinfo = "update `lv_users` set `verification_code` = '$shuffled' where  `email` = '$email'";
		 $result = $database->query($updateuserinfo);
		
	
      $return_array = success("Your Lecture Verb verification code has been successfully sent to your email.");
    } else {
      $return_array = failure("Error with email client, Please try again later..");
    }
  }
  else {
    $return_array = failure("The email address is not associated with us. Please enter a valid email address.");
  }
  return $return_array;

 }
 
 /**
	 *
	 *GET USER ROLE
	 *
	**/
	
	function get_user_role(){
					$database = new medoo();
     $data = array();
					$GetUserRoles= "SELECT * from `lv_users_role`";								
								 $GetUserRolesResult = $database->query($GetUserRoles);
									if ($GetUserRolesResult !== FALSE)
									{
													$GetUserRolesResultUser=$GetUserRolesResult->fetchAll(PDO::FETCH_ASSOC);
													
													 $return_array = success("successfully, List of Users role.");
														$return_array['data'] = $GetUserRolesResultUser;	
														
									} else
									{
													$return_array = failure("Incorrect code entered.");
													
									}
									
		  return $return_array;
		
	}
		
		 	 
	


/**
 *
 *Registration Signup use for social login too
 *
 */
function signup($parameters){
     $database = new medoo();
     $data = array();

 $data['full_name'] = $parameters['full_name'];
	$data['role_id'] = $parameters['role_id'];
	$data['email'] = ($parameters['email'] ? $parameters['email'] : 'no@email.com');
	$data['password'] = $parameters['password'];	
	$data['register_via'] = 'manual';
	$data['social_id'] = ($parameters['social_id'] ? $parameters['social_id'] : '0');
	$data['profile_pic'] = ($parameters['profile_pic'] ? $parameters['profile_pic'] : '/assets/img/no-images.jpg' );
	$data['device_token'] = ($parameters['device_token'] ? $parameters['device_token'] : '0' );
	$data['device_type'] = $parameters['device_type'];

          $data['status'] = 0; 
                if( user_existed( $parameters["email"] ) )
               {
                         //$str = 'Q1H*';
					$shuffled = generateRandomString();
					$data['verification_code'] = $shuffled;
                    $last_user_id = $database->insert("lv_users",$data);
           
                    if($last_user_id)
                       {
					
																									
                         $return_array = success("User registered successfully, Please verify your email id");
                         $data["user_id"] = $last_user_id;
                         $return_array['data'] = get_user_data($last_user_id);
						 sendverificationemail($parameters["email"], $shuffled);
                       }
                  else
                       {
                         $return_array = Failure("Registration Failed");
                       }
               }
          else
          {
												
			  if(CheckAccountVerification($parameters['email']))
						{

								 $return_array = Failure("User already existed with this email");

						}
					else{

								$user_id_byemail =   user_id_by_email($parameters['email']); 
								$return_array = failure("Email verification is pending for this email id.");
								$return_array['data'] = get_user_data($user_id_byemail);

						}		
																	
           
          }
      

     return $return_array;
   
   }
			
/***
 *
 *Social Login
 *
 **/			
			
			
			
			function social_login($parameters){
				     $database = new medoo();
     $data = array();
				 $data['full_name'] = $parameters['full_name'];
					$data['role_id'] = $parameters['role_id'];
					$data['email'] = ($parameters['email'] ? $parameters['email'] : 'no@email.com');
					//$data['password'] = '';
					$data['register_via'] = $parameters['register_via'];
					$data['profile_pic'] = ($parameters['profile_pic'] ? $parameters['profile_pic'] : '/assets/img/no-images.jpg' );
					$data['social_id'] = $parameters['social_id'];	
					$data['device_token'] = ($parameters['device_token'] ? $parameters['device_token'] : '0' );
					$data['device_type'] = $parameters['device_type'];
					//$data['status'] = 0; 
				
				
					 
      //// when social login or sign up
        $data['status'] = 1;
								$user_details = '';
								$last_user_id = '';
								$sid = $parameters['social_id'];
								$eid =  $parameters['email'];
								 $query = "SELECT `user_id`,`email`,`social_id` FROM `lv_users` WHERE `social_id` = '$sid' OR `email` = '$eid' LIMIT 1";								
								 $result = $database->query($query);
									if ($result !== FALSE)
									{
													$user_details=$result->fetchAll(PDO::FETCH_ASSOC);
									} else
									{
													// Alternative code telling what to do when the query fails
													
									}

							//	print_r($user_details);	die;
	     //if($user_details['0']['user_id']){ $last_user_id = $user_details[0]['user_id'];}
						 $last_user_id = $user_details[0]['user_id']; 
          if($last_user_id){
//              	 if(CheckAccountVerification($parameters['email']))
//				 { // check account verification
					
					 
					 $ToKEN = $data["device_token"];
					 $devicetype = $data["device_type"];
					 $database->myupdate("UPDATE `lv_users` SET `device_type` = '".$devicetype."' , `device_token`= '".$ToKEN."' WHERE `user_id` ='".$last_user_id."'");
					 $return_array = success("Login Successful");
					 $return_array['data'] = get_user_data($last_user_id);
					// $message = "Login Successful";
					
			//	 }
			//else
			//	{
			//		$return_array = failure("Email verification is pending for this email id.");
			//		$return_array['data'] = get_user_data($last_user_id);
			//	}
			
          }
          
          else
          {
               
               $last_user_id = $database->insert("lv_users",$data);
														
                if( $last_user_id ){
                  $return_array = success("User registered successfully");
                  $return_array['data'] = get_user_data($last_user_id);
                }else{
                  $return_array = failure("Registration Failed");
                }
          }

						return $return_array;
				
			}



 /**
 *
 * SIGN IN Login
 *
 */  

function login($parameters){
  $database = new medoo();
  $return_array = array();
  
  
  $user_id_byemail = $database->get("lv_users", "user_id", ["AND" => ["email" => $parameters['email'],	"password" => $parameters['password']]]);

  if($user_id_byemail){
	 if(CheckAccountVerification($parameters['email']))
	 { // check account verification 
	
		 $device_token =  $parameters['device_token'];
		 $device_type = $parameters['device_type'];
		 
		 $updateuserinfo = "update `lv_users` set `device_token` = '' where  `device_token` = '$device_token'";
		 $result = $database->query($updateuserinfo);
	   
		 $updateuserinfo = "update `lv_users` set `device_type` = '$device_type' , `device_token` = '$device_token' where user_id = $user_id_byemail";
		 $result = $database->query($updateuserinfo);
		 
		 
		 $return_array = success("Login Successful");
		 $return_array['data'] = get_user_data($user_id_byemail);
    
    	}
	else
	{
		$return_array = failure("Email verification is pending for this email id.");
		$return_array['data'] = get_user_data($user_id_byemail);
	}
    
    
    
  }else{
    $return_array = failure("Email/password mismatch or does not exist.");
  }
  return $return_array;
}


/*
*
*
* Logout user
*
*
*/

 function logout($parameters)
    {
      $database = new medoo();
      $return_array = array();
      if(isset($parameters['user_id']))
      {
        $user_id = $parameters['user_id'];
        $database->update("lv_users", [ "device_token" => '' ], [ "user_id" => $user_id ]);
        $return_array = success("Successfully signout.");
      }
      else
      {
       $return_array = failure("failed to logout, Please try again.");
      }
      return $return_array;
    }





/*
 *
 *emailverification
 *
 **/

 function emailverification($parameters){
	  $database = new medoo();
       $return_array = array();
	
	$user_id_byemail = $database->get("lv_users", "user_id", ["AND" => ["user_id" => $parameters['user_id'] , "email" => $parameters['email'],	"verification_code" => $parameters['verification_code']]]);
	//echo $database->last_query(); die;
    if($user_id_byemail)
	{
		/// update user status 
		$updateuserinfo = "update `lv_users` set `status` = '1' where  `user_id` =". $parameters['user_id'];
		 $result = $database->query($updateuserinfo);
		 
		 $return_array = success("Email verified successfully, Login to your account.");
		 $return_array['data'] = get_user_data($parameters['user_id']);
			 
	}
	else
	{
		 $return_array = failure("Incorrect code entered.");
	}
  return $return_array;
	
	
 }





 /**
 *
 * FORGOT PASSWORD
 *
 */ 

function forgot_password($email){
  $return_array = array();
  $data = array();
  $database = new medoo();
  $select_user = "SELECT `full_name`, `email`, `password` FROM `lv_users` WHERE `email`='$email' LIMIT 1";
  //print_r ($select_user);
  $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
  if(count($result) > 0) {
    $name = $result[0]['full_name'];
    $to = $result[0]['email'];
    $password = $result[0]['password'];
    $msg ='<!doctype html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>LectureVerb Forgot Password Mail</title>
      </head>
      <body style="margin:0px; padding:0px;overflow-y:auto;overflow-x:hidden;" >
        <span style="font-size:15px; color:black; padding:5px; margin:0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;">Hi '.$name.'</span>';
        $msg .= '<span style="font-size:15px; color:black; padding:5px; margin:10px 0 0 0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;">Here is your password.</span>';
        $msg .= '<span style="letter-spacing:10px; font-size:30px; color:black; padding:5px; margin:10px 0 0 0px; float:left; font-family:Gotham, Helvetica Neue, Helvetica, Arial, sans-serif; width:100%;">'.$password.'</span><br/></body></html>';
    $subject = "Hi ".$name.", Your LectureVerb App Password Request..";
    if(mymail($to, $subject, $msg)){
      $return_array = success("Your LectureVerb password has been successfully sent to your email.");
    } else {
      $return_array = failure("Error with email client, Please try again later..");
    }
  }
  else {
    $return_array = failure("The email address is not associated with us. Please enter a valid email address.");
  }
  return $return_array;
}




/***
 *
 *Update Student data use if student have university data like name and id 
 *
 **/

function submit_student_data()
	{
		
							$database = new medoo();
       $return_array = array();
							
							$data['role_id'] = $_REQUEST['role_id'];
							$data['user_id'] = $_REQUEST['user_id'];
							$data['student_id'] = $_REQUEST['student_id'];
							$data['name_of_instituted'] = $_REQUEST['name_of_instituted'];
							
						 $last_user_id = $database->insert("lv_student_info",$data);
							
							//echo $database->last_query(); die;
							
									if( $last_user_id ){
											$return_array = success("Data Added successfully");
									}
									else{
											$return_array = failure("Failed");
               }
						
						return $return_array;										

	}



/***
 *
 *Update Device Token
 *
 **/

function update_device_token($parameters)
	{
			    $database = new medoo();
                $return_array = array();
							$device_token = $parameters['device_token'];
							$userid = $parameters['user_id'];
                            
                            $selectUser_id = "SELECT `user_id` from `lv_users` WHERE `device_token` = '$device_token'";                           
                            $selectUser_idresult = $database->query($selectUser_id);//->fetchAll(PDO::FETCH_ASSOC);
                            if($selectUser_idresult)
                            {
                                    $user_details=$selectUser_idresult->fetchAll(PDO::FETCH_ASSOC);
                                    $updateuserinfo3 = "UPDATE `lv_users` set `device_token` = '' where  `user_id` = ".$user_details[0]['user_id'];
                                    $result3 = $database->query($updateuserinfo3);
                        }
                        
                $updateuserinfo = "update `lv_users` set `device_token` = '$device_token' where  `user_id` = $userid";
                $result = $database->query($updateuserinfo);			
							if( $result ){
											$return_array = success("Token updated successfully");
									}
									else{
											$return_array = failure("Failed");
                                    }						
						return $return_array;			
	}	
	
/*
 *
 *Update User Profile
 *
 */

    function update_profile($parameters){
      $return_array = array();
      $database = new medoo();
      $data = array();
      $user_id = $parameters["user_id"];
      $data['full_name'] = $parameters["full_name"];
      $data['bio'] = $parameters["bio"];
						$data['location'] = $parameters["location"];
						$data['lat'] = $parameters["lat"];
						$data['lang'] = $parameters["lang"];
						$data['website'] = $parameters["website"]; 
      $update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);
      $return_array = success("Profile updated successfully.");
      $return_array['data'] = get_user_data($user_id);
    
      return $return_array;
    
    }


/**
 *
 * Update only Profile image 
 *
 */

function update_profile_image($parameters){
   $return_array = array();
   $database = new medoo();
   $data = array();
   $user_id = $parameters["user_id"];
   $target_path = UPLOADS_URL ."/profile/";
   $random = md5(uniqid());
			if($_REQUEST['upload_type'] == 'upload')
			{
							if(isset($_FILES['profile_image']) && !empty($_FILES['profile_image'])){
									$ext = explode('.', basename($_FILES['profile_image']['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
								
									if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_path)) {
											$data['profile_pic'] = '/uploads/profile/'. $random . "." . $ext[count($ext) - 1];
											$update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);
											$return_array = success("Profile updated successfully.");
											$return_array['data'] = get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}
			}
			
			else{
				
											$data['profile_pic'] = ($_REQUEST['profile_image'] ? $_REQUEST['profile_image'] :  '/assets/img/no-images.jpg') ;
											$update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);
											$return_array = success("Profile updated successfully.");
				
				
			}
			
   return $return_array;

}


/**
 *
 * Update only Profile cover image 
 *
 */

function update_profile_cover_image($parameters){
   $return_array = array();
   $database = new medoo();
   $data = array();
   $user_id = $parameters["user_id"];
   $target_path = UPLOADS_URL ."/cover/";
   $random = md5(uniqid());
			if($_REQUEST['upload_type'] == 'upload')
			{
							if(isset($_FILES['cover_image']) && !empty($_FILES['cover_image'])){
									$ext = explode('.', basename($_FILES['cover_image']['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];

									if (move_uploaded_file($_FILES['cover_image']['tmp_name'], $target_path)) {
											$data['cover_pic'] = '/uploads/cover/'. $random . "." . $ext[count($ext) - 1];
											$update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);
											$return_array = success("Profile updated successfully.");
											$return_array['data'] = get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}
			}
			
			else{
				
											$data['cover_pic'] = ($_REQUEST['cover_image'] ? $_REQUEST['cover_image'] :  '/assets/img/no-images.jpg') ;
											$update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);
											$return_array = success("Profile updated successfully.");
				
				
			}
			
   return $return_array;

}


/**
 *
 *Update User Notification Setting
 *
 */

	function update_user_notification($parameters){
				$return_array = array();
				$database = new medoo();
				$data = array();
				$user_id = $parameters["user_id"];
				$status = $parameters["allow_notification"]=='Y' ? 'Yes' : 'No';
				$data['allow_notification'] = $status;				
				$update = $database->update("lv_users", $data, [ "user_id" => $user_id ]);				
				$return_array = success("Notification Updated to ".$status );
				$return_array['allow_notification'] = $database->get("lv_users", "allow_notification", ["user_id" => $user_id]);
				return $return_array;
	
	}

/**
 *
 *Insert User Ash Tags
 *
 **/

	function add_user_ash_tags($parameters){
					$return_array = array();
		 		$database = new medoo();
			 	$data = array();

					
					$data['user_id'] = $parameters["user_id"];
					//$data['tag_name'] = $parameters["tag_name"];
					
					$datauser_id = $parameters["user_id"];
					//$datatag_name = $parameters["tag_name"];
					$datatag_name = explode('|' , $parameters["tag_name"]);
		
                    $checkduplicatetageforsameuser2 = "DELETE FROM `lv_ash_tags` WHERE `user_id` = '$datauser_id'";
                    $checkTag2= $database->query($checkduplicatetageforsameuser2)->fetchAll(PDO::FETCH_ASSOC);
					
                    // check if same tag is added by same user
                    //$checkduplicatetageforsameuser = "SELECT `tag_name` FROM `lv_ash_tags` WHERE `user_id` = $datauser_id AND  `tag_name` = '$datatag_name'";
	
foreach($datatag_name as $key => $datatag_nameValue) :	
		
	$data['tag_name'] = $datatag_nameValue;
	$checkduplicatetageforsameuser = "SELECT `tag_name` FROM `lv_ash_tags` WHERE `tag_name` = '$datatag_nameValue'";
    $checkTag = $database->query($checkduplicatetageforsameuser)->fetchAll(PDO::FETCH_ASSOC);
//print_r($checkTag); die;
	 if($checkTag)
		{
			 //$return_array = success("Tag Insert Successfully.");
		}

		else{
				$last_tag_id = $database->insert("lv_ash_tags",$data);

			}
		
endforeach;
		

		$return_array = success("Tag Insert Successfully.");
		
					return $return_array;
	}

	
/**
 *
 *GETt User Ash Tags
 *
 **/

	function get_ash_tags($parameters){
		
				$return_array = array();
		   		$database = new medoo();
			   	$data = array();
				$datauser_id = $parameters["user_id"];
				$keyword = $parameters["tag_name"];
		
		
		 		//$checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE `user_id` = $datauser_id";
		 		//$checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE `tag_name` like '%".$keyword."%'";
                
                $checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE user_id=$datauser_id";
                //echo $checkduplicatetageforsameuser;die;
                $checkTag = $database->query($checkduplicatetageforsameuser)->fetchAll(PDO::FETCH_ASSOC);
					
					 if($checkTag)
							{
									$return_array = success("Tag Insert Successfully.");
									$return_array['data']  =$checkTag;									
							}
		 
			  else{
						
						 $return_array = failure("Error: There is no tags found in database.");	
						
					}
					
				return $return_array;
		
	}
	
	
    
    
    
/**
 *
 *GETt User Ash Tags
 *
 **/

	function get_all_hash_tags($parameters){
		
				$return_array = array();
		   		$database = new medoo();
			   	$data = array();
				$keyword = $parameters["tag_name"];
		
		
		 		//$checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE `user_id` = $datauser_id";
		 		$checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE `tag_name` like '%".$keyword."%'";
                //$checkduplicatetageforsameuser = "SELECT `tag_name` , `tag_id` FROM `lv_ash_tags` WHERE user_id=$datauser_id";
                //echo $checkduplicatetageforsameuser;die;
                $checkTag = $database->query($checkduplicatetageforsameuser)->fetchAll(PDO::FETCH_ASSOC);
					
					 if($checkTag)
							{
									$return_array = success("This is all tags list");
									$return_array['data']  =$checkTag;									
							}
		 
			  else{
						
						 $return_array = failure("Error: There is no tags found in database.");	
						
					}
					
				return $return_array;
		
	}
	
	
    
    
    
	
	
/**
 *
 *Add Quick Lecture
 *
 *
 */
	
	
	
function add_quick_lecture($parameters){
	$return_array = array();
	$database = new medoo();
	$data = array();
	$user_id = $parameters["user_id"];
	$quick_lecture_type = $_REQUEST['quick_lecture_type'];
    $user_name = $_REQUEST['user_name'];
	//$time =  utc_date();
                    $getfo['user_id'] = $parameters["user_id"];
                    $getmyfollowers = get_my_followers($getfo);
                
                //echo "<pre>";print_r($getmyfollowers); die();
    
    
	 if($quick_lecture_type === 'audio' || $quick_lecture_type === 'video' || $quick_lecture_type === 'discovery_video'  || $quick_lecture_type === 'discovery_audio' ){
		$target_path = UPLOADS_URL ."/quick_lecture/".$quick_lecture_type."/";
		$random = md5(uniqid());

		if(isset($_FILES[$quick_lecture_type]) && !empty($_FILES[$quick_lecture_type])){
			$ext = explode('.', basename($_FILES[$quick_lecture_type]['name']));
			$file_extension = end($ext);
			$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
			
			if (move_uploaded_file($_FILES[$quick_lecture_type]['tmp_name'], $target_path)) {
						
				$data['file_path'] = '/uploads/quick_lecture/'.$quick_lecture_type.'/'. $random . "." . $ext[count($ext) - 1];
				$data['quick_lecture_type'] = $_REQUEST['quick_lecture_type'];
				$data['user_id'] = $user_id;
				$data['quick_lecture_text'] = trim(($_REQUEST['quick_lecture_text'] ? $_REQUEST['quick_lecture_text'] : '' ));
			    $data['privacy'] = $_REQUEST['privacy'];
			    $data['discovery_url'] = $_REQUEST['discovery_url'];
			    $data['quick_lecture_time_duration'] = $_REQUEST['quick_lecture_time_duration'];					   
			    $data['history_stack'] = $_REQUEST['history_stack'];					   
                $data["date_time"] = utc_date();
                $data["reposted_date_time"] = utc_date();
				

	//echo "<pre>";print_r($data); die;
				$last_insert_id = $database->insert("lv_quick_lecture",$data);
				//$last_insert_id = $database->update("lv_quick_lecture",$data);
				
				$data['quick_lecture_id'] = $last_insert_id;
				//echo  $database->last_query();
				if($last_insert_id){									
					$return_array = success("Quick Lecture added successfully.");
					$return_array['data'] = $data;//get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
					 //$database->get("lv_users", "*", ["user_id" => $user_id]);										        
				}else{
					$return_array = failure("Error Inserting quick lecture");
					//$return_array['query'] = $database->last_query();
				}
			}else{
				$return_array = failure("Error uploading image");
			}
		}else{
			$return_array = failure("Error: There is some problem with image file");
		}
	}else{
		//$data['file_path'] = '';					
		$data['user_id'] = $user_id;
		$data['quick_lecture_type'] = $_REQUEST['quick_lecture_type'];
		$data['quick_lecture_text'] = $_REQUEST['quick_lecture_text'];
		$data['history_stack'] = $_REQUEST['history_stack'];
        $lecture_name  =$_REQUEST['quick_lecture_text']; 
		//$data['privacy'] = $_REQUEST['privacy'];
		//$data['discovery_url'] = $_REQUEST['discovery_url'];				
						$data["date_time"] = utc_date();
						$data["reposted_date_time"] = utc_date();
		$last_insert_id = $database->insert("lv_quick_lecture",$data);
		//$last_insert_id = $database->update("lv_quick_lecture",$data, ["AND" => ["user_id" => $user_id , "quick_lecture_id" => 1]]);

		$data['quick_lecture_id'] = $last_insert_id; 
		if($last_insert_id){						
			$return_array = success("Lecture posted successfully.");
			$return_array['data'] = $data; //get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
       /******* Send Notification to followers****/      
            foreach($getmyfollowers['data'] as $getmyfollowersval)
                { 
                              
                            if($getmyfollowersval['device_token']!="")
                            {
                                $notifMessage = "";
                                if($user_name== ""){
                                       $notifMessage =  "You have new unseen lecture '".$lecture_name."'";
                                }else{
                                         $notifMessage =  $user_name. " has posted a new lecture '".$lecture_name."'";
                            }
                                  $msgg['flag'] = "16";
                                  $msgg['user_id'] = $user_id;
                                  $msgg['quick_lecture_id'] = $last_insert_id;
                                  $msgg['msg'] =$notifMessage; 
                                  sendFcmeNotification($msgg,$getmyfollowersval['device_token']);
                           }
            }
          /******* Send Notification to followers****/   
		}else{
			$return_array = failure("Error Inserting quick lecture");
		}
	}
	return $return_array;
}
	
	



	
/**
 *
 *Update Quick Lecture
 *
 *
 */
	
	
	
	function update_quick_lecture($parameters){
   $return_array = array();
   $database = new medoo();
   $data = array();
   $user_id = $parameters["user_id"];
   $quick_lecture_id = $parameters["quick_lecture_id"];
	$quick_lecture_type = $_REQUEST['quick_lecture_type'];
		
//print_r($_FILES);
		if($_FILES[$quick_lecture_type]['size'] != 0)
		{
			 if($quick_lecture_type === 'audio' || $quick_lecture_type === 'video'|| $quick_lecture_type === 'discovery_video'  || $quick_lecture_type === 'discovery_audio' )
				{
						
									
						$target_path = UPLOADS_URL ."/quick_lecture/".$quick_lecture_type."/";
						$random = md5(uniqid());

							if(isset($_FILES[$quick_lecture_type]) && !empty($_FILES[$quick_lecture_type])){
									$ext = explode('.', basename($_FILES[$quick_lecture_type]['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
								
									if (move_uploaded_file($_FILES[$quick_lecture_type]['tmp_name'], $target_path)) {
											
											$data['file_path'] = '/uploads/quick_lecture/'.$quick_lecture_type.'/'. $random . "." . $ext[count($ext) - 1];
											$data['quick_lecture_type'] = $_REQUEST['quick_lecture_type'];
											$data['user_id'] = $user_id;
											$data['quick_lecture_text'] = trim(($_REQUEST['quick_lecture_text'] ? $_REQUEST['quick_lecture_text'] : '' ));
										    $data['privacy'] = $_REQUEST['privacy'];
										    $data['discovery_url'] = $_REQUEST['discovery_url'];
										   
											$dateupdate= utc_date();
											//$last_insert_id = $database->insert("lv_quick_lecture",$data);
											$last_insert_id = $database->update("lv_quick_lecture",$data, ["AND" => ["user_id" => $user_id , "quick_lecture_id" => $quick_lecture_id] , "date_time" => $dateupdate]);
										
										 $data['quick_lecture_id'] = $last_insert_id;
										//echo  $database->last_query();
											if($last_insert_id)
												{
												
															$return_array = success("Quick Lecture added successfully.");
															$return_array['data'] = $data;//get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
															 //$database->get("lv_users", "*", ["user_id" => $user_id]);
													        
												}
												
											else{
												$return_array = failure("Error Inserting quick lecture");
										}	
												
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}

				}
				else{
					
					      					//$data['file_path'] = '';					
											$data['user_id'] = $user_id;
											$data['quick_lecture_type'] = $_REQUEST['quick_lecture_type'];
											$data['quick_lecture_text'] = $_REQUEST['quick_lecture_text'];
											$data['discovery_url'] = $_REQUEST['discovery_url'];
											$data['privacy'] = $_REQUEST['privacy'];
											//$data['privacy'] = $_REQUEST['privacy'];
					 						//$data['discovery_url'] = $_REQUEST['discovery_url'];
											
																$dateupdate= utc_date();
											//$last_insert_id = $database->insert("lv_quick_lecture",$data);
											$last_insert_id = $database->update("lv_quick_lecture",$data, ["AND" => ["user_id" => $user_id , "quick_lecture_id" => $quick_lecture_id] , "date_time" =>$dateupdate]);
					
					 						$data['quick_lecture_id'] = $last_insert_id; 
											if($last_insert_id)
												{
												
															$return_array = success("Quick lecture successfully.");
															$return_array['data'] = $data; //get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
													        
												}
												
											else{
												$return_array = failure("Error Inserting quick lecture 1111");
										}					
				}	
		}
		
		
		else{ 
			
											$data['user_id'] = $user_id;
											$data['quick_lecture_type'] = $_REQUEST['quick_lecture_type'];
											$data['quick_lecture_text'] = $_REQUEST['quick_lecture_text'];
											$data['discovery_url'] = $_REQUEST['discovery_url'];
											$data['privacy'] = $_REQUEST['privacy'];
											//$data['privacy'] = $_REQUEST['privacy'];
					 						//$data['discovery_url'] = $_REQUEST['discovery_url'];
											
												$dateupdate= utc_date();
											//$last_insert_id = $database->insert("lv_quick_lecture",$data);
											$last_insert_id = $database->update("lv_quick_lecture",$data, ["AND" => ["user_id" => $user_id , "quick_lecture_id" => $quick_lecture_id] , "date_time" => $dateupdate]);
					//echo $database->last_query(); die;
					 						$data['quick_lecture_id'] = $last_insert_id; 
											if($last_insert_id)
												{
												
															$return_array = success("Quick lecture successfully.");
															$return_array['data'] = $data; //get_user_data($user_id); //$database->get("lv_users", "*", ["user_id" => $user_id]);
													        
												}
												
											else{
												$return_array = failure("Error Inserting quick lecture");
										}
		
		
		}

			
   return $return_array;

}








/**
 *
 * Add Update Quick Lecture Thumbnil image  
 *
 */

function update_quick_lecture_thumbnail($parameters){
   $return_array = array();
   $database = new medoo();
   $data = array();
   $quick_lecture_id = $parameters["quick_lecture_id"];
   
   $target_path = UPLOADS_URL ."/quick_lecture/thumbnail/";
   $random = md5(uniqid());
			if($_REQUEST['upload_type'] == 'upload')
			{
							if(isset($_FILES['thumbnail']) && !empty($_FILES['thumbnail'])){
									$ext = explode('.', basename($_FILES['thumbnail']['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];

									if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_path)) {
											$data['thumbnail'] = '/uploads/quick_lecture/thumbnail/'. $random . "." . $ext[count($ext) - 1];
										    $ata['quick_lecture_id'] = $quick_lecture_id;
												$data['date_time'] =		$dateupdate= utc_date();
											$update = $database->update("lv_quick_lecture", $data, [ "quick_lecture_id" => $quick_lecture_id]);
											$return_array = success("Thumbnail updated successfully.");
											$return_array['data'] =	$data;		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}
			}
			
			else{
				
											$data['thumbnail'] = ($parameters['thumbnail'] ? $parameters['thumbnail'] :  '/assets/img/no-images.jpg') ;
											$data['quick_lecture_id'] = $quick_lecture_id;
													$dateupdate= utc_date();
											$update = $database->update("lv_quick_lecture", $data, [ "quick_lecture_id" => $quick_lecture_id , "date_time" => $dateupdate]);
											
											$return_array = success("Thumbnail updated successfully.");
											$return_array['data'] =	$data;
				
				
			}
			
   return $return_array;

}






	
/**
 *
 *GETt Quick Lectures
 *
 **/

	function get_posted_lectures($parameters){
		
		$return_array = array();
		$database = new medoo();
		$data = array();
		$datauser_id = $parameters["user_id"];

		$page = $parameters['page'];
		if($parameters["page"]==""){$page=1;}
		$items_per_page = 10;
		$offset = ($page - 1) * $items_per_page;
		$limit = " limit " . $offset . "," . $items_per_page; 

 		//$GetQuicklectureaudiovideo = "SELECT * FROM `lv_quick_lecture` WHERE `user_id` = $datauser_id ORDER BY `quick_lecture_id` DESC $limit";
 		//$GetQuicklectureaudiovideo = "SELECT * FROM `lv_quick_lecture` ORDER BY `quick_lecture_id` DESC $limit";
		//$GetQuicklectureaudiovideo = "SELECT type, quick_lecture_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,event_id,user_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,date_time FROM (SELECT 'lecture' as type, quick_lecture_id, user_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,'' as event_id,'' as lecture_title,'' as lecture_poster,'' as recording_type,'' as address,'' as latitude,'' as longitude,'' as details,'' as can_invite_friends,'' as lecturer_co_hosts,'' as lecture_subject_tags,'' as isPublic,'' as lecture_start_date_time,'' as lecture_end_date_time,date_time FROM `lv_quick_lecture` where user_id IN (SELECT DISTINCT CASE WHEN follower_user_id = $datauser_id THEN followed_user_id ELSE follower_user_id END userID from lv_followers) UNION ALL SELECT 'event' as type, '' as quick_lecture_id,user_id,'' as category_id,'' as quick_lecture_type,'' as file_path,'' as quick_lecture_text,'' as thumbnail,'' as discovery_url,'' as privacy,'' as lecture_view,'' as quick_lecture_time_duration, event_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,lecture_created_date_time as date_time FROM `lv_events` where user_id IN (SELECT DISTINCT CASE WHEN follower_user_id = $datauser_id THEN followed_user_id ELSE follower_user_id END userID from lv_followers)) t ORDER BY date_time DESC $limit";
		//
		
		$GetQuicklectureaudiovideo =   "SELECT case when (date_time > reposted_date_time) THEN date_time ELSE reposted_date_time END as sortbydate, type, quick_lecture_id, history_stack, reposted_date_time,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,event_id,user_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,date_time,reposted_by FROM (SELECT '' as sortbydate, 'lecture' as type, quick_lecture_id,history_stack,reposted_date_time, user_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,'' as event_id,'' as lecture_title,'' as lecture_poster,'' as recording_type,'' as address,'' as latitude,'' as longitude,'' as details,'' as can_invite_friends,'' as lecturer_co_hosts,'' as lecture_subject_tags,'' as isPublic,'' as lecture_start_date_time,'' as lecture_end_date_time,date_time, '' as reposted_by FROM `lv_quick_lecture` where user_id IN (SELECT followed_user_id as userID from lv_followers where follower_user_id = $datauser_id ) UNION ALL SELECT '' as sortbydate ,'event' as type, '' as quick_lecture_id,'' as history_stack,'' as reposted_date_time,user_id,'' as category_id,'' as quick_lecture_type,'' as file_path,'' as quick_lecture_text,'' as thumbnail,'' as discovery_url,'' as privacy,'' as lecture_view,'' as quick_lecture_time_duration, event_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,lecture_created_date_time as date_time , '' as reposted_by FROM `lv_events` where user_id IN (SELECT followed_user_id as userID from lv_followers where follower_user_id = $datauser_id )
		
		
UNION
SELECT '' as sortbydate, 'lecture' as type, lect.quick_lecture_id,history_stack, reposted_date_time,lect.user_id,lect.category_id,lect.quick_lecture_type,lect.file_path,lect.quick_lecture_text,lect.thumbnail,lect.discovery_url,lect.privacy,lect.lecture_view,lect.quick_lecture_time_duration,'' 
as event_id,'' as lecture_title,'' as lecture_poster,'' as recording_type,'' as address,'' as latitude,'' as longitude,'' as details,'' as can_invite_friends,'' as lecturer_co_hosts,'' 
as lecture_subject_tags,'' as isPublic,'' as lecture_start_date_time,'' as lecture_end_date_time,lect.date_time ,repost.user_id as reposted_by
FROM lv_lecture_repost_status as repost join `lv_quick_lecture` lect on repost.quick_lecture_id=lect.quick_lecture_id where repost.parent_lecture_user_id = $datauser_id
		) t ORDER BY sortbydate DESC $limit";
		
/*SELECT type, quick_lecture_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,event_id,user_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,date_time 

FROM (SELECT "lecture" as type, quick_lecture_id, user_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,"" as event_id,"" as lecture_title,"" as lecture_poster,"" as recording_type,"" as address,"" as latitude,"" as longitude,"" as details,"" as can_invite_friends,"" as lecturer_co_hosts,"" as lecture_subject_tags,"" as isPublic,"" as lecture_start_date_time,"" as lecture_end_date_time,date_time FROM `lv_quick_lecture` where user_id IN (SELECT DISTINCT CASE WHEN follower_user_id = '6' THEN followed_user_id ELSE follower_user_id END userID from lv_followers)
UNION ALL
SELECT "event" as type, "" as quick_lecture_id,user_id,"" as category_id,"" as quick_lecture_type,"" as file_path,"" as quick_lecture_text,"" as thumbnail,"" as discovery_url,"" as privacy,"" as lecture_view,"" as quick_lecture_time_duration, event_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,lecture_created_date_time as date_time FROM `lv_events` where user_id IN (SELECT DISTINCT CASE WHEN follower_user_id = '6' THEN followed_user_id ELSE follower_user_id END userID from lv_followers))
t
ORDER BY date_time*/

        $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
		//print_r($GetQuicklectureaudiovideoMani); die;
		if($GetQuicklectureaudiovideoMani){
			foreach($GetQuicklectureaudiovideoMani as $key => $GetQuicklectureaudiovideoManiValue){
				
				$checkrepost = ($GetQuicklectureaudiovideoManiValue['reposted_by'] == "" ? $GetQuicklectureaudiovideoManiValue['user_id'] : $GetQuicklectureaudiovideoManiValue['reposted_by'] );
		
				

				if($GetQuicklectureaudiovideoManiValue['type']=="lecture"){
					$GetQuicklectureaudiovideoManiValueArray[$key] = array_merge($GetQuicklectureaudiovideoManiValue , get_all_countsof_leacture($GetQuicklectureaudiovideoManiValue['quick_lecture_id']));
					
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_liked'] = (string)is_liked($GetQuicklectureaudiovideoManiValue['quick_lecture_id'], $datauser_id);
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_favourite'] = (string)is_favourite($GetQuicklectureaudiovideoManiValue['quick_lecture_id'], $datauser_id);
					//$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data($GetQuicklectureaudiovideoManiValue['user_id']);
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_reposted'] = check_is_reposted($datauser_id,$GetQuicklectureaudiovideoManiValue['quick_lecture_id']);
					
						$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data(($GetQuicklectureaudiovideoManiValueArray[$key]['is_reposted'] == 'true' ? $datauser_id : $checkrepost));
					
					$GetQuicklectureaudiovideoManiValueArray[$key]['event_interest'] = get_lecture_orevent_interest($GetQuicklectureaudiovideoManiValue['quick_lecture_id'],'lecture');
					$GetQuicklectureaudiovideoManiValueArray[$key]['event_interest'] = get_lecture_orevent_interest($GetQuicklectureaudiovideoManiValue['quick_lecture_id'],'lecture');
					
					$GetQuicklectureaudiovideoManiValueArray[$key]['reposted_lecture_id'] = check_is_reposted_lecture_id($datauser_id,$GetQuicklectureaudiovideoManiValue['quick_lecture_id']);
					
					$GetQuicklectureaudiovideoManiValueArray[$key]['lecturer_co_hosts'] = [];
				}else{
					$GetQuicklectureaudiovideoManiValueArray[$key] = $GetQuicklectureaudiovideoManiValue;
					$GetCoHostsID = explode(',' , $GetQuicklectureaudiovideoManiValue['lecturer_co_hosts']);												
					foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
					{
						$getUsaeDate = '';				
						$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
						$getUsaeDate =  get_user_data($int);
						 if($getUsaeDate)
						 {
							$Get_Users_Data_CoHosts[] = $getUsaeDate;
						 }

					}
					

					$GetQuicklectureaudiovideoManiValueArray[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
					$GetQuicklectureaudiovideoManiValueArray[$key]['Isinterested'] = check_event_attend_and_interest($GetQuicklectureaudiovideoManiValue['user_id'] ,  $GetQuicklectureaudiovideoManiValue['event_id']);
					$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data($checkrepost);
				}
				
								//$UID = $GetQuicklectureaudiovideoManiValue['user_id'];
								$LID = $GetQuicklectureaudiovideoManiValue['quick_lecture_id'];
					   $GetparentLectureUserID = "SELECT `parent_lecture_user_id` from `lv_lecture_repost_status` where `quick_lecture_id` = '$LID' AND `user_id` = '$checkrepost'";
        $GetparentLectureUserID_main = $database->query($GetparentLectureUserID)->fetchAll(PDO::FETCH_ASSOC);
								$GetQuicklectureaudiovideoManiValueArray[$key]['OwnerUserdata'] = ($GetparentLectureUserID_main['0']['parent_lecture_user_id'] ? get_user_data($GetparentLectureUserID_main['0']['parent_lecture_user_id']) : get_user_data($GetQuicklectureaudiovideoManiValue['user_id']));

			}
			$return_array = success("List of quick lecture.");
			$return_array['data']  = $GetQuicklectureaudiovideoManiValueArray;
		}else{
			 $return_array = failure("Error: There is no lecture found in database.");
		}
//		echo $GetparentLectureUserID;
//echo "<pre>";print_r($GetparentLectureUserID_main); 
		return $return_array;
	}


	
/**
 *
 *GET my Quick Lectures by my user_id
 *
 **/

	function get_my_posted_lectures($parameters){
		
		$return_array = array();
		$database = new medoo();
		$data = array();
		$datauser_id = $parameters["user_id"];

		//$other_user_id = ($parameters["other_user_id"] ? $parameters["other_user_id"] : $datauser_id );
		
				$other_user_id = $parameters["other_user_id"];
		
		$page = $parameters['page'];
		if($parameters["page"]==""){$page=1;}
		$items_per_page = 10;
		$offset = ($page - 1) * $items_per_page;
		$limit = " limit " . $offset . "," . $items_per_page; 

 		//$GetQuicklectureaudiovideo = "SELECT * FROM `lv_quick_lecture` WHERE `user_id` = $datauser_id ORDER BY `quick_lecture_id` DESC $limit";
 		//$GetQuicklectureaudiovideo = "SELECT * FROM `lv_quick_lecture` ORDER BY `quick_lecture_id` DESC $limit";
		$GetQuicklectureaudiovideo = "SELECT case when (date_time > reposted_date_time) THEN date_time ELSE reposted_date_time END as sortbydate, type, quick_lecture_id,history_stack,reposted_date_time,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,event_id,user_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,date_time FROM (SELECT '' as sortbydate ,'lecture' as type, quick_lecture_id,history_stack,reposted_date_time, user_id,category_id,quick_lecture_type,file_path,quick_lecture_text,thumbnail,discovery_url,privacy,lecture_view,quick_lecture_time_duration,'' as event_id,'' as lecture_title,'' as lecture_poster,'' as recording_type,'' as address,'' as latitude,'' as longitude,'' as details,'' as can_invite_friends,'' as lecturer_co_hosts,'' as lecture_subject_tags,'' as isPublic,'' as lecture_start_date_time,'' as lecture_end_date_time,date_time FROM `lv_quick_lecture` where user_id = $datauser_id UNION ALL SELECT '' as sortbydate ,'event' as type, '' as quick_lecture_id,'' as history_stack,'' as reposted_date_time,user_id,'' as category_id,'' as quick_lecture_type,'' as file_path,'' as quick_lecture_text,'' as thumbnail,'' as discovery_url,'' as privacy,'' as lecture_view,'' as quick_lecture_time_duration, event_id,lecture_title,lecture_poster,recording_type,address,latitude,longitude,details,can_invite_friends,lecturer_co_hosts,lecture_subject_tags,isPublic,lecture_start_date_time,lecture_end_date_time,lecture_created_date_time as date_time FROM `lv_events` where user_id=$datauser_id 
UNION

SELECT '' as sortbydate , 'lecture' as type, lect.quick_lecture_id,history_stack,reposted_date_time, lect.user_id,lect.category_id,lect.quick_lecture_type,lect.file_path,lect.quick_lecture_text,lect.thumbnail,lect.discovery_url,lect.privacy,lect.lecture_view,lect.quick_lecture_time_duration,'' 
as event_id,'' as lecture_title,'' as lecture_poster,'' as recording_type,'' as address,'' as latitude,'' as longitude,'' as details,'' as can_invite_friends,'' as lecturer_co_hosts,'' 
as lecture_subject_tags,'' as isPublic,'' as lecture_start_date_time,'' as lecture_end_date_time,lect.date_time 
FROM lv_lecture_repost_status as repost join `lv_quick_lecture` lect on repost.quick_lecture_id=lect.quick_lecture_id where repost.user_id = $datauser_id  ) t ORDER BY sortbydate DESC $limit";

        $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
		if($GetQuicklectureaudiovideoMani){
			foreach($GetQuicklectureaudiovideoMani as $key => $GetQuicklectureaudiovideoManiValue){

				if($GetQuicklectureaudiovideoManiValue['type']=="lecture"){
					$GetQuicklectureaudiovideoManiValueArray[$key] = array_merge($GetQuicklectureaudiovideoManiValue , get_all_countsof_leacture($GetQuicklectureaudiovideoManiValue['quick_lecture_id']));
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_liked'] = (string)is_liked($GetQuicklectureaudiovideoManiValue['quick_lecture_id'], $other_user_id);
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_favourite'] = (string)is_favourite($GetQuicklectureaudiovideoManiValue['quick_lecture_id'], $other_user_id);
					$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data($datauser_id);
					//	$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data($GetQuicklectureaudiovideoManiValue['user_id']);
					
					$GetQuicklectureaudiovideoManiValueArray[$key]['event_interest'] = get_lecture_orevent_interest($GetQuicklectureaudiovideoManiValue['quick_lecture_id'],'lecture');
					$GetQuicklectureaudiovideoManiValueArray[$key]['event_interest'] = get_lecture_orevent_interest($GetQuicklectureaudiovideoManiValue['quick_lecture_id'],'lecture');
					$GetQuicklectureaudiovideoManiValueArray[$key]['is_reposted'] = check_is_reposted($datauser_id,$GetQuicklectureaudiovideoManiValue['quick_lecture_id']);
					$GetQuicklectureaudiovideoManiValueArray[$key]['reposted_lecture_id'] = check_is_reposted_lecture_id($datauser_id,$GetQuicklectureaudiovideoManiValue['quick_lecture_id']);
					$GetQuicklectureaudiovideoManiValueArray[$key]['lecturer_co_hosts'] = [];
				}else{
					$GetQuicklectureaudiovideoManiValueArray[$key] = $GetQuicklectureaudiovideoManiValue;
					$GetCoHostsID = explode(',' , $GetQuicklectureaudiovideoManiValue['lecturer_co_hosts']);												
					foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
					{
						$getUsaeDate = '';				
						$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
						$getUsaeDate =  get_user_data($int);
						 if($getUsaeDate)
						 {
							$Get_Users_Data_CoHosts[] = $getUsaeDate;
						 }

					}

					$GetQuicklectureaudiovideoManiValueArray[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
					$GetQuicklectureaudiovideoManiValueArray[$key]['Isinterested'] = check_event_attend_and_interest($other_user_id ,  $GetQuicklectureaudiovideoManiValue['event_id']);
					$GetQuicklectureaudiovideoManiValueArray[$key]['Userdata'] = get_user_data($GetQuicklectureaudiovideoManiValue['user_id']);
				}
				
								$LID = $GetQuicklectureaudiovideoManiValue['quick_lecture_id'];
					   $GetparentLectureUserID = "SELECT `parent_lecture_user_id` from `lv_lecture_repost_status` where `quick_lecture_id` = '$LID' AND `user_id` = '$datauser_id'";
        $GetparentLectureUserID_main = $database->query($GetparentLectureUserID)->fetchAll(PDO::FETCH_ASSOC);
								$GetQuicklectureaudiovideoManiValueArray[$key]['OwnerUserdata'] = ($GetparentLectureUserID_main['0']['parent_lecture_user_id'] ? get_user_data($GetparentLectureUserID_main['0']['parent_lecture_user_id']) : NULL);

			}
			$return_array = success("List of quick lecture.");
			$return_array['data']  = $GetQuicklectureaudiovideoManiValueArray;
		}else{
			 $return_array = failure("Error: There is no lecture found in database.");
		}

		return $return_array;
	}


 /**
 *
 * POST Like/Dislike wish
 *
 */
    function like_unlike_lecture($parameters){
        $return_array = array();
        $database = new medoo();
        $data['quick_lecture_id'] = $parameters["quick_lecture_id"];
        $data['user_id'] = $parameters["user_id"];
        $data['is_liked'] = "1";
        $data["date_time"] = utc_date();
								$data1["date_time"] = utc_date();
        $quick_lecture_id = $parameters["quick_lecture_id"];
        $userid = $parameters["user_id"];
        $query = "select count(*) as cnt from lv_likes where quick_lecture_id='".$data['quick_lecture_id']."' and user_id='".$data['user_id']."'";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        if($posts[0]['cnt']==0) {
              $insert = $database->insert("lv_likes", $data);
														
													//	$update = $database->update("lv_quick_lecture", $data1, [ "quick_lecture_id" => $quick_lecture_id]);
              $return_array = success("Liked successfully");
              $return_array["like_id"] = $insert;
              $actionn = "liked";
        }else{
              $database->delete("lv_likes",["AND" => ["quick_lecture_id" => $quick_lecture_id , "user_id" => $userid ] ]);
              $return_array = success("Unliked Successfully");
              $return_array["like_id"] = [];
              $actionn = "unliked";
        }

        if($actionn=="liked"){
          $notified_user = get_quick_lecture_user_details($quick_lecture_id);
          $notified_user_details = get_user_name_by_id($userid);

          
          if($data['user_id']!=$notified_user['user_id']){
            ###### save notifications #####
              $notif_msg = "Your Lecture (".$notified_user['quick_lecture_text'].") is $actionn by ".ucwords($notified_user_details['full_name']); 
              notify_user($notified_user['user_id'],$userid,$notif_msg,$quick_lecture_id,$actionn,'lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
            ###### save notifications #####
            ###### push notification ######
             
              if($notified_user['device_token']!=""){
                  $msgg['flag'] = "3";
                  $msgg['user_id'] = $notified_user['user_id'];
                  $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                  $msgg['msg'] = "Your Lecture (".$notified_user['quick_lecture_text'].") is $actionn by ".ucwords($notified_user_details['full_name']); 
                  sendFcmeNotification($msgg,$notified_user['device_token']);
              }
            ###### push notification ######
          }
			
			
			
			
        }

        return $return_array;
    }
	




 /**
 *
 * Add Remove Lecture From Favourite List
 *
 */
    function add_remove_to_favourite_list($parameters){
        $return_array = array();
        $database = new medoo();
        $data['quick_lecture_id'] = $parameters["quick_lecture_id"];
        $data['user_id'] = $parameters["user_id"];
        $data['is_favourite'] = "1";
        $data["date_time"] = utc_date();
								$data1["date_time"] = utc_date();
        $quick_lecture_id = $parameters["quick_lecture_id"];
        $userid = $parameters["user_id"];
        $query = "select count(*) as cnt from lv_favourite_list where quick_lecture_id='".$data['quick_lecture_id']."' and user_id='".$data['user_id']."'";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        if($posts[0]['cnt']==0) {
              $insert = $database->insert("lv_favourite_list", $data);
													//	$update = $database->update("lv_quick_lecture", $data1, [ "quick_lecture_id" => $quick_lecture_id]);
              $return_array = success("Added to favorite list");
              $return_array["favourite"] = $insert;
              $actionn = "favourite";
        }else{
              $database->delete("lv_favourite_list",["AND" => ["quick_lecture_id" => $quick_lecture_id , "user_id" => $userid ] ]);
              $return_array = success("Removed from favorite list");
              $return_array["favourite"] = [];
              $actionn = "unfavourite";
        }

       // if($actionn=="favourite"){
          $notified_user = get_quick_lecture_user_details($quick_lecture_id);
          $notified_user_details = get_user_name_by_id($userid);
          if($data['user_id']!=$notified_user['user_id']){
            ###### save notifications #####
              $notif_msg = "Your Lecture (".$notified_user['quick_lecture_text'].") is added to $actionn list by ".ucwords($notified_user_details['full_name']); 
              notify_user($notified_user['user_id'],$userid,$notif_msg,$quick_lecture_id,$actionn,'lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
            ###### save notifications #####
            ###### push notification ######
              if($notified_user['device_token']!=""){
                  $msgg['flag'] = $actionn=="favourite" ? "4" : "11";
                  $msgg['user_id'] = $notified_user['user_id'];
                  $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                  $msgg['msg'] = "Your Lecture (".$notified_user['quick_lecture_text'].") is added to $actionn list by ".ucwords($notified_user_details['full_name']); 
                  sendFcmeNotification($msgg,$notified_user['device_token']);
              }
            ###### push notification ######
          }
        //}
        return $return_array;
    }
/**
 *
 *GETt Quick Lectures
 *
 **/

	function get_lectures_by_id($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$datauser_id = $parameters["quick_lecture_id"];
		
		
		 		$GetQuicklectureaudiovideo = "SELECT * FROM `lv_quick_lecture` WHERE `quick_lecture_id` = $datauser_id";
     $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
					
					 
						if($GetQuicklectureaudiovideoMani)
						{
								$GetQuicklectureaudiovideoMani[0]['lecture_interest'] = get_lecture_orevent_interest( $datauser_id,'lecture');
						}
					
					else{
							$GetQuicklectureaudiovideoMani;
					}
				//return ($GetQuicklectureaudiovideoMani ?  $GetQuicklectureaudiovideoMani : '');
				return $GetQuicklectureaudiovideoMani ;
		
	}





/**
 *
 *GETT Liked Lectures
 *
 **/

	function get_liked_lectures($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$datauser_id = $parameters["user_id"];		
		
		
				$page = $parameters['page'];
				if($parameters["page"]==""){$page=1;}
				$items_per_page = 10;
				$offset = ($page - 1) * $items_per_page;
				$limit = " limit " . $offset . "," . $items_per_page; 
		
		
		 		$GetQuicklectureaudiovideo = "SELECT `quick_lecture_id` FROM `lv_likes` WHERE `user_id` = $datauser_id ORDER BY `like_id` DESC $limit";
                $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
				
				if(!empty($GetQuicklectureaudiovideoMani))
				{	
					foreach($GetQuicklectureaudiovideoMani as $GetQuicklectureaudiovideoManivalue)
						{

							 $data['quick_lecture_id'] = $GetQuicklectureaudiovideoManivalue['quick_lecture_id'];

								$likedlecture[] = get_lectures_by_id($data);

						}

					$return_array = success("Liked Lecture list.");
					$return_array['data'] = $likedlecture;
				}
		
		else{
			
				$return_array = failure("No like list found.");
				$return_array['data'] = [];
		
		    }
		return $return_array;
					
	}






/**
 *
 *GETT favourite  Lectures
 *
 **/

	function get_favourite_lectures($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$datauser_id = $parameters["user_id"];		
		
		
				$page = $parameters['page'];
				if($parameters["page"]==""){$page=1;}
				$items_per_page = 10;
				$offset = ($page - 1) * $items_per_page;
				$limit = " limit " . $offset . "," . $items_per_page; 
		
		
		 		$GetQuicklectureaudiovideo = "SELECT `quick_lecture_id` , `user_id` FROM `lv_favourite_list` WHERE `user_id` = $datauser_id ORDER BY `date_time` DESC $limit";
                $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
				
				if(!empty($GetQuicklectureaudiovideoMani))
				{	//echo "<pre>"; print_r($GetQuicklectureaudiovideoMani);
					foreach($GetQuicklectureaudiovideoMani as $key => $GetQuicklectureaudiovideoManivalue)
						{
											
							 	$data['quick_lecture_id'] = $GetQuicklectureaudiovideoManivalue['quick_lecture_id'];
								$datauser_id = $GetQuicklectureaudiovideoManivalue['user_id'];

								$GetQuicklectureaudiovideoManiValueArray = get_lectures_by_id($data);
							    $GetQuicklectureaudiovideoManiValueArray12 = $GetQuicklectureaudiovideoManiValueArray[0];
							
								$GetQuicklectureaudiovideoManiValueArray1[$key] = array_merge($GetQuicklectureaudiovideoManiValueArray12 , get_all_countsof_leacture($GetQuicklectureaudiovideoManivalue['quick_lecture_id']));
								$GetQuicklectureaudiovideoManiValueArray1[$key]['is_liked'] = (string)is_liked($GetQuicklectureaudiovideoManivalue['quick_lecture_id'], $datauser_id);
								$GetQuicklectureaudiovideoManiValueArray1[$key]['is_favourite'] = (string)is_favourite($GetQuicklectureaudiovideoManivalue['quick_lecture_id'], $datauser_id);							
								$GetQuicklectureaudiovideoManiValueArray1[$key]['Userdata'] = get_user_data($GetQuicklectureaudiovideoManivalue['user_id']);

						}

					$return_array = success("Favourite Lecture list.");
					$return_array['data'] = $GetQuicklectureaudiovideoManiValueArray1;
				}
		
		else{
			
				$return_array = failure("No favourite list found.");
				$return_array['data'] = [];
		
		    }
		return $return_array;
					
	}





/**
 *
 *GETt Quick Lectures
 *
 **/

	function add_lecture_to_recent_played_list($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$data['user_id'] = $parameters["user_id"];
				$data['quick_lecture_id'] = $parameters["quick_lecture_id"];
		        $lectureud = $parameters['quick_lecture_id'];
				//$data['page'] = 1;
		 		
                $GETRESENTLECTUREPLAYLISID = $database->insert("lv_recent_lecture_played_list" , $data);	
				
		if($GETRESENTLECTUREPLAYLISID)
			{
				$updateuserinfo = "update `lv_quick_lecture` set `lecture_view` = lecture_view + 1 where  `quick_lecture_id` = $lectureud";
		    	$result = $database->query($updateuserinfo);
					
					$return_array = success("Lecture Add to played list successfully");
					$return_array['date'] =  get_lectures_by_id($data);
			}	
		else{
					$return_array = failure("Error Inserting lecture to recent playd list");
					$return_array['date'] =  get_lectures_by_id($data);
		
		    }
					
				return $return_array;
		
	}




/**
 *
 *GETt Quick Lectures
 *
 **/

	function get_recent_played_lectures($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$datauser_id = $parameters["user_id"];		
		
		
				$page = $parameters['page'];
				if($parameters["page"]==""){$page=1;}
				$items_per_page = 10;
				$offset = ($page - 1) * $items_per_page;
				$limit = " limit " . $offset . "," . $items_per_page; 
		
		
		 		$GetQuicklectureaudiovideo = "SELECT `quick_lecture_id` FROM `lv_recent_lecture_played_list` WHERE `user_id` = $datauser_id GROUP BY `quick_lecture_id` ORDER BY `recent_lecture_played_list_id` DESC $limit";
                $GetQuicklectureaudiovideoMani = $database->query($GetQuicklectureaudiovideo)->fetchAll(PDO::FETCH_ASSOC);
				//print_r($GetQuicklectureaudiovideoMani);
				if(!empty($GetQuicklectureaudiovideoMani))
				{	
					foreach($GetQuicklectureaudiovideoMani as $GetQuicklectureaudiovideoManivalue)
						{
								
							 $data['quick_lecture_id'] = $GetQuicklectureaudiovideoManivalue['quick_lecture_id'];

								$likedlecture[] = get_lectures_by_id($data);

						}

					$return_array = success("Recent Lecture played Lecture list.");
					$return_array['data'] = $likedlecture;
				}
		
		else{
			
				$return_array = failure("No Recent played list found.");
				$return_array['data'] = [];
		
		    }
		return $return_array;
		
	}





/*
 *
 * Create lecture events 
 * OR upcoming lecture
 *
 */


function create_lecture_event($parameters){

	$return_array = array();
	$database = new medoo();
	$data = array();
	//echo "<pre>"; print_r($_REQUEST); die;
	
	$data['user_id'] = $parameters['user_id'];
	$data['lecture_title'] = $parameters['lecture_title'];
	//$data['lecture_poster'] = $parameters['lecture_poster']; /// lecture image
	$data['recording_type'] = $parameters['recording_type']; // / pre_recorded / live_recorded
	$data['lecture_start_date_time'] = $parameters['lecture_start_date_time'];
	$data['lecture_end_date_time'] = $parameters['lecture_end_date_time'];
	$data['address'] = $parameters['address'];
	$data['latitude'] = $parameters['latitude'];
	$data['longitude'] = $parameters['longitude'];
	$data['details'] = $parameters['details'];
	$data['can_invite_friends'] = $parameters['can_invite_friends'];  // True OR false
	$data['lecturer_co_hosts'] = $parameters['lecturer_co_hosts']; // addd comma separated user_ids
	$data['lecture_subject_tags'] = $parameters['lecture_subject_tags'];
	$data['isPublic'] = $parameters['isPublic'];  // True or false
	$data['lecture_created_date_time'] = utc_date();
	
        $user_name = $parameters['user_name'];

                    $getfo['user_id'] = $parameters["user_id"];
                    $getmyfollowers = get_my_followers($getfo);
	//echo "<pre>"; print_r($data); die;
	
	    $target_path = UPLOADS_URL ."/lecture_event/event_poster/";
   		$random = md5(uniqid());
			
							if(isset($_FILES['lecture_poster']) && !empty($_FILES['lecture_poster'])){
									$ext = explode('.', basename($_FILES['lecture_poster']['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];

									if (move_uploaded_file($_FILES['lecture_poster']['tmp_name'], $target_path)) {
											$data['lecture_poster'] = '/uploads/lecture_event/event_poster/'. $random . "." . $ext[count($ext) - 1];
										    $ata['quick_lecture_id'] = $quick_lecture_id;
											$InsertEvent = $database->insert("lv_events", $data);
                                            
                                            /******* Send Notification to followers****/
                                                        foreach($getmyfollowers['data'] as $getmyfollowersval)
                                                                        { 
                                                                                      
                                                                                    if($getmyfollowersval['device_token']!="")
                                                                                    {
                                                                                          $msgg['flag'] = "17";
                                                                                          $msgg['user_id'] = $data['user_id'] ;
                                                                                          $msgg['event_id'] = $InsertEvent;
                                                                                          $msgg['msg'] = "$user_name has posted a new $lecture_name"; 
                                                                                          sendFcmeNotification($msgg,$getmyfollowersval['device_token']);
                                                                                   }
                                                                        }
                                                /******* Send Notification to followers****/
										    $data['event_id'] = $InsertEvent;
										if($InsertEvent)
										{
											$return_array = success("Thumbnail updated successfully.");
											$return_array['data'] =	$data;		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
										}
										else{
											$return_array = failure("Error in creating lecture event.");
											$return_array['data'] =	[];		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
											$return_array['query'] = $database->last_query();
										}
										
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}
		
	return $return_array;


}





/*
 *
 * Update lecture events 
 * OR upcoming lecture
 *
 */


function update_lecture_event($parameters){

	$return_array = array();
	$database = new medoo();
	$data = array();
	//echo "<pre>"; print_r($_REQUEST); die;
	
	$user_id = $parameters['user_id'];
	$data['lecture_title'] = $parameters['lecture_title'];
	//$data['lecture_poster'] = $parameters['lecture_poster']; /// lecture image
	$data['recording_type'] = $parameters['recording_type']; // / pre_recorded / live_recorded
	$data['lecture_start_date_time'] = $parameters['lecture_start_date_time'];
	$data['lecture_end_date_time'] = $parameters['lecture_end_date_time'];
	$data['address'] = $parameters['address'];
	$data['latitude'] = $parameters['latitude'];
	$data['longitude'] = $parameters['longitude'];
	$data['details'] = $parameters['details'];
	$data['can_invite_friends'] = $parameters['can_invite_friends'];  // True OR false
	$data['lecturer_co_hosts'] = $parameters['lecturer_co_hosts']; // addd comma separated user_ids
	$data['lecture_subject_tags'] = $parameters['lecture_subject_tags'];
	$data['isPublic'] = $parameters['isPublic'];  // True or false
	$data['lecture_created_date_time'] = utc_date();
	$EventID = $parameters['event_id'];
	
            $user_name = $parameters['user_name'];

                    $getfo['user_id'] = $parameters["user_id"];
                    $getmyfollowers = get_my_followers($getfo);
	//echo "<pre>"; print_r($data); die;
	
		if($_FILES['lecture_poster']['size'] != 0)
		{	
	    $target_path = UPLOADS_URL ."/lecture_event/event_poster/";
   		$random = md5(uniqid());
			
							if(isset($_FILES['lecture_poster']) && !empty($_FILES['lecture_poster'])){
									$ext = explode('.', basename($_FILES['lecture_poster']['name']));
									$file_extension = end($ext);
									$target_path = $target_path . $random . "." . $ext[count($ext) - 1];

									if (move_uploaded_file($_FILES['lecture_poster']['tmp_name'], $target_path)) {
											$data['lecture_poster'] = '/uploads/lecture_event/event_poster/'. $random . "." . $ext[count($ext) - 1];
										    $ata['quick_lecture_id'] = $quick_lecture_id;
											$InsertEvent = $database->update("lv_events", $data , ["AND" => ["user_id" => $user_id , "event_id" => $EventID]]);
										    $data['event_id'] = $InsertEvent;
										if($InsertEvent)
										{
											    $Event['event_id'] = $EventID;
											    $Event['hideresponce']	= true;
												$responce =  get_single_lecture_event($Event);
											
					
												 $GetCoHostsID = explode(',' , $responce['lecturer_co_hosts']);
												
												foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
												{
													$getUsaeDate = '';				
													$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
													$getUsaeDate =  get_user_data($int);
													 if($getUsaeDate)
													 {
														$Get_Users_Data_CoHosts[] = $getUsaeDate;
													 }

												}

												$responce['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
											
											
											$return_array = success("Event updated successfully.");
											$return_array['data'] =	$responce;		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
                                        /******* Send Notification to followers****/
                                                        foreach($getmyfollowers['data'] as $getmyfollowersval)
                                                                        { 
                                                                                      
                                                                                    if($getmyfollowersval['device_token']!="")
                                                                                    {
                                                                                          $msgg['flag'] = "18";
                                                                                          $msgg['user_id'] = $user_id ;
                                                                                          $msgg['event_id'] = $EventID;
                                                                                          $msgg['msg'] = "$user_name has posted a new $lecture_name"; 
                                                                                          sendFcmeNotification($msgg,$getmyfollowersval['device_token']);
                                                                                   }
                                                                        }
                                                /******* Send Notification to followers****/
                                            
                                            
										}
										else{
											$return_array = failure("Error in creating lecture event.");
											$return_array['data'] =	[];		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
											$return_array['query'] = $database->last_query();
										}
										
									}else{
												$return_array = failure("Error uploading image");
									}
							}else{
										$return_array = failure("Error: There is some problem with image file");
							}
		}
	
	else{
	
								$InsertEvent = $database->update("lv_events", $data , ["AND" => ["user_id" => $user_id , "event_id" => $EventID]]);
							   
										if($InsertEvent)
										{
											$Event['event_id'] = $EventID;
											$Event['hideresponce']	= true;
												$responce =  get_single_lecture_event($Event);
											
					
												 $GetCoHostsID = explode(',' , $responce['lecturer_co_hosts']);
												
												foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
												{
													$getUsaeDate = '';				
													$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
													$getUsaeDate =  get_user_data($int);
													 if($getUsaeDate)
													 {
														$Get_Users_Data_CoHosts[] = $getUsaeDate;
													 }

												}

												$responce['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
											
								
											
											
											$return_array = success("Event updated successfully.");
											$return_array['data'] =	$responce;		
                                            
                                                /******* Send Notification to followers****/
                                                        foreach($getmyfollowers['data'] as $getmyfollowersval)
                                                                        { 
                                                                                      
                                                                                    if($getmyfollowersval['device_token']!="")
                                                                                    {
                                                                                          $msgg['flag'] = "18";
                                                                                          $msgg['user_id'] = $user_id ;
                                                                                          $msgg['event_id'] = $EventID;
                                                                                          $msgg['msg'] = "$user_name has posted a new $lecture_name"; 
                                                                                          sendFcmeNotification($msgg,$getmyfollowersval['device_token']);
                                                                                   }
                                                                        }
                                                /******* Send Notification to followers****/
										}
										else{
											$return_array = failure("Error in creating lecture event.");
											$return_array['data'] =	[];		//get_user_data($user_id);//$database->get("lv_users", "*", ["user_id" => $user_id]);
											$return_array['query'] = $database->last_query();
										}
	
	
	}
		
	return $return_array;


}








/**
 *
 *GETt Lectures Event
 *
 **/

	function get_lecture_event($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$datauser_id = $parameters["user_id"];	
                
		
		        $datauser_idcheck = ($parameters["user_id"] ? " user_id = $datauser_id AND " : ''); 
		
				$page = $parameters['page'];
				if($parameters["page"]==""){$page=1;}
				$items_per_page = 10;
				$offset = ($page - 1) * $items_per_page;
				$limit = " limit " . $offset . "," . $items_per_page; 
		
		
		 
		 		//$GetLectureEvent = "SELECT * FROM `lv_events` WHERE $datauser_idcheck `lecture_end_date_time`  > NOW() ORDER BY `lecture_start_date_time` $limit";
		 if($parameters["action"] == 'upcoming' ){$GetLectureEvent = "SELECT * FROM `lv_events` WHERE `lecture_end_date_time`  > NOW() ORDER BY `lecture_start_date_time` $limit";}
			if($parameters["action"] == 'mylist' ){$GetLectureEvent = "SELECT * FROM `lv_events` WHERE `user_id` = $datauser_id ORDER BY `event_id` DESC $limit";}
                $GetLectureEventMain = $database->query($GetLectureEvent)->fetchAll(PDO::FETCH_ASSOC);
				//print_r($GetLectureEventMain);
				if(!empty($GetLectureEventMain))
				{	
					foreach($GetLectureEventMain as $key => $GetLectureEventMainValue)
						{
											$GetLectureEventMainValue['event_interest'] = get_lecture_orevent_interest($GetLectureEventMainValue['event_id'],'event');
											
							    $lectureevents[$key] = $GetLectureEventMainValue;
							   	$lectureevents[$key]['Userdata'] = get_user_data($GetLectureEventMainValue['user_id']);
								$lectureevents[$key]['event_interest'] = get_lecture_orevent_interest($GetLectureEventMainValue['event_id'],'event');

							    $lectureevents[$key]['Isinterested'] = check_event_attend_and_interest($datauser_id ,  $GetLectureEventMainValue['event_id']);
							    $lectureevents[$key]['Isinvited'] = invited($datauser_id ,  $GetLectureEventMainValue['event_id']);
							
								$GetCoHostsID = explode(',' , $GetLectureEventMainValue['lecturer_co_hosts']);
								
								$Get_Users_Data_CoHosts = array();
								foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
									{
										$getUsaeDate = '';				
										$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
										$getUsaeDate =  get_user_data($int);
										 if($getUsaeDate)
										 {
											$Get_Users_Data_CoHosts[] = $getUsaeDate;
										 }

									}
					
								$lectureevents[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
							
							
							

						}

					$return_array = success("Lecture Event list.");
					$return_array['data'] = $lectureevents;
				}
		
		else{
			
				$return_array = failure("No Recent Lecture events list found.");
				$return_array['data'] = [];
		
		    }
		return $return_array;
		
	}





/**
 *
 *GETt Lectures Event
 *
 **/

	function get_single_lecture_event($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				$event_id = $parameters["event_id"];
				
		
		
		 		$GetLectureEvent = "SELECT * FROM `lv_events` WHERE `event_id` = $event_id";
                $GetLectureEventMain = $database->query($GetLectureEvent)->fetchAll(PDO::FETCH_ASSOC);
				//print_r($GetLectureEventMain);
				if(!empty($GetLectureEventMain))
				{	
					
									$user_id = ($parameters["user_id"] ? $parameters["user_id"] : $GetLectureEventMain['0']['user_id'] );	
							   // $lectureevents[$key] = $GetLectureEventMainValue;
									$GetLectureEventMain[0]['event_interest'] = get_lecture_orevent_interest($event_id,'event');
								 $GetLectureEventMain[0]['Userdata'] = get_user_data($GetLectureEventMain['0']['user_id']);
								 $GetLectureEventMain[0]['Isinterested'] = check_event_attend_and_interest($user_id ,  $event_id);
								 $GetLectureEventMain[0]['Isinvited'] = invited($GetLectureEventMain['0']['user_id'] ,  $event_id);


								$GetCoHostsID = explode(',' , $GetLectureEventMain['0']['lecturer_co_hosts']);
										
								$Get_Users_Data_CoHosts = array();				
								foreach($GetCoHostsID as $ke => $GetCoHostsIDMain){
									$getUsaeDate = '';				
									$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
									$getUsaeDate =  get_user_data($int);
									 if($getUsaeDate)
									 {
										$Get_Users_Data_CoHosts[] = $getUsaeDate;
									 }

								}

								$GetLectureEventMain[0]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );

					$return_array = success("Single Event.");
					
					$return_array['data'] = $GetLectureEventMain;
				}
		
		else{
			
				$return_array = failure("Invalid Event id.");
				$return_array['data'] = [];
		
		    }
		if($parameters['hideresponce']  != 'true' ) {$main = $return_array; } else { $main = $return_array['data']['0'];}
		return $main;
		
	}

/*
*
*Wite comment on lecture
*
*/



function lecture_write_comment($parameters){
        $return_array = array();
        $database = new medoo();
        $data['user_id'] = $parameters["user_id"];
        $data['quick_lecture_id'] = $parameters["quick_lecture_id"];
        $data['comment'] = $parameters["comment"];
        $data['date_time'] = utc_date();

        //for files
        	$data['comment_type'] = $parameters["comment_type"];
									
	        $target_path = UPLOADS_URL ."/comments/";
									$target_path_thumb = UPLOADS_URL ."/comments/thumb/";
									
									//echo"<pre>"; print_r($_FILES); die;
									
	   		$random = md5(uniqid());
		   	if($_REQUEST['comment_type'] == 'f'){//f-file,t-text
				if(isset($_FILES['comment_file']) && !empty($_FILES['comment_file'])){
					$ext = explode('.', basename($_FILES['comment_file']['name']));
					$file_extension = end($ext);
					
					$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
					$target_path_thumb = $target_path_thumb . $random . "." . $ext[count($ext) - 1];
					
					if (move_uploaded_file($_FILES['comment_file']['tmp_name'], $target_path)) {
						$data['comment_file'] = '/uploads/comments/'. $random . "." . $ext[count($ext) - 1];
						$data['file_extension'] = $parameters['file_extension'];
					}else{
						$return_array = failure("Error uploading file");
					}
					
					if (move_uploaded_file($_FILES['comment_thumb']['tmp_name'], $target_path_thumb)) {
						$data['comment_thumb'] = '/uploads/comments/thumb/'. $random . "." . $ext[count($ext) - 1];
						//$data['thumbnail'] = $parameters['thumbnail'];
					}else{
						$return_array = failure("Error uploading thumbnail");
					}
					
					
				}else{
					$return_array = failure("Error: There is some problem with file");
				}
			}
   		//for files
							
							$data['date_time'] = utc_date();
					
        $last_comment_id = $database->insert("lv_comments", $data);
        if($last_comment_id) {
			$return_array = success("Comment added successfully");
			$comments_query = "select * from lv_comments where comment_id='".$last_comment_id."'";
			$comments_data = $database->query($comments_query)->fetchAll(PDO::FETCH_ASSOC);
			$return_array["data"] = $comments_data;
			
			  $notified_user = get_quick_lecture_user_details($parameters["quick_lecture_id"]);			
			  $notified_user_details = get_user_name_by_id($parameters["user_id"]);

              
              if($data['user_id']!=$notified_user['user_id']){
                  ###### save notifications #####
				  $actionn = 'comment';
                    $notif_msg = "Your Lecture (".$notified_user['quick_lecture_text'].") is Commented by ".ucwords($notified_user_details['full_name']); 
                    notify_user($notified_user['user_id'],$data['user_id'],$notif_msg,$data['quick_lecture_id'],$actionn,'lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
				  //echo $database->last_query(); die;
                  ###### save notifications #####
        
                $getmyfollowers = get_lecture_user_like_comment_reposted($parameters["quick_lecture_id"]);
                //print_r($getmyfollowers);die;
                /******* Send Notification to followers****/
               foreach($getmyfollowers as $getmyfollowersval)
               {                                                                                      
                if($getmyfollowersval['device_token']!="")
                    {
                        $messageText = "Lecture (".$notified_user['quick_lecture_text'].") is Commented by ".ucwords($notified_user_details['full_name']);
                        notify_user($getmyfollowersval['user_id'],$data['user_id'],$messageText,$data['quick_lecture_id'],$actionn,'lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
                        
                        $msgg['flag'] = "5";
                        $msgg['user_id'] = $notified_user['user_id'] ;
                        $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                        $msgg['msg'] = $messageText; 
                        sendFcmeNotification($msgg,$getmyfollowersval['device_token']);
                    }
               }                                         
               /******* Send Notification to followers****/

                  ###### push notification ######
                    
                    if($notified_user['device_token']!=""){
                        $msgg['flag'] = "5";
                        $msgg['user_id'] = $notified_user['user_id'];
                        $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                        $msgg['msg'] = "Your Lecture (".$notified_user['quick_lecture_text'].") is Commented by ".ucwords($notified_user_details['full_name']); 
                        sendFcmeNotification($msgg,$notified_user['device_token']);
                    }
                  ###### push notification ######
              }


        }else{
              $return_array = failure("Error in adding comment");
              $return_array["data"] = ""; 
        }
        return $return_array;
    }

/*
*
*Write comment reply
*
*/



    function write_comment_reply($parameters){
        $return_array = array();
        $database = new medoo();
        $data['user_id'] = $parameters["user_id"];
        $data['quick_lecture_id'] = $parameters["quick_lecture_id"];
        $data['comment_id'] = $parameters["comment_id"];        
        $data['comment_reply'] = $parameters["comment"];
        $data['date_time'] = utc_date();

        //for files
        	$data['comment_type'] = $parameters["comment_type"];
									
	        $target_path = UPLOADS_URL ."/comments/";
									$target_path_reply = UPLOADS_URL ."/comments/reply_thumb/";
	   		$random = md5(uniqid());
		   	if($_REQUEST['comment_type'] == 'f'){//f-file,t-text

				if(isset($_FILES['comment_file']) && !empty($_FILES['comment_file'])){
					$ext = explode('.', basename($_FILES['comment_file']['name']));
					$file_extension = end($ext);
					
					$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
					$target_path_reply = $target_path_reply . $random . "." . $ext[count($ext) - 1];
					
					if (move_uploaded_file($_FILES['comment_file']['tmp_name'], $target_path)) {
						$data['comment_file'] = '/uploads/comments/'. $random . "." . $ext[count($ext) - 1];
						$data['file_extension'] = $parameters['file_extension'];
					}else{
						$return_array = failure("Error uploading file");
					}
					
				if (move_uploaded_file($_FILES['reply_thumb']['tmp_name'], $target_path_reply)) {
						$data['reply_thumb'] = '/uploads/comments/reply_thumb/'. $random . "." . $ext[count($ext) - 1];
						//$data['thumbnail'] = $parameters['thumbnail'];
					}else{
						$return_array = failure("Error uploading thumbnail");
					}
					
					
				}else{
					$return_array = failure("Error: There is some problem with file");
				}
			}
   		//for files

        $last_reply_id = $database->insert("lv_comments_reply", $data);
		
        if($last_reply_id) {
				$return_array = success("Comment added successfully");
				$comments_reply_query = "select * from lv_comments_reply where comment_reply_id='".$last_reply_id."'";
				$comments_reply_data = $database->query($comments_reply_query)->fetchAll(PDO::FETCH_ASSOC);
				$return_array["data"] = $comments_reply_data;

				$notified_user = get_quick_lecture_user_details($data['quick_lecture_id']);
				$notified_user_details = get_user_name_by_id($parameters["user_id"]);
				//print_r($notified_user); die;
				// $notified_user_details = get_user_name_by_id($parameters["user_id"]);
              
              if($data['user_id']!=$notified_user['user_id']){
                ###### save notifications #####
				  $actionn = 'comment_reply';
                  $notif_msg = ucwords($notified_user_details['full_name'])." replied on your comment"; 
                  notify_user($notified_user['user_id'],$data['user_id'],$notif_msg,$data['quick_lecture_id'],$actionn,'lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
                ###### save notifications #####

                ###### push notification ######
                 
                  if($notified_user['device_token'] !=""){
                      //$sender_name = get_user_name_by_id($data['user_id']);
                      $msgg['flag'] = "5";
                      $msgg['user_id'] = $notified_user['user_id'];
                      $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                      $msgg['msg'] = ucwords($notified_user['full_name'])." replied on your comment"; 
                      sendFcmeNotification($msgg,$notified_user['device_token']);
                  }
                ###### push notification ######
              }
        }else{
              $return_array = failure("Error in adding comment");
              $return_array["comment_reply_id"] = ""; 
        }
        return $return_array;
    }


/*
*
*Get Comment Lists
*
*/

    function comments_list($parameters){
        $return_array = array();
        $database = new medoo();
        $user_id = $parameters["user_id"];
        $quick_lecture_id = $parameters["quick_lecture_id"];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

         $commentsquery = "select c1.*, (SELECT c2.user_id FROM lv_comments_reply as c2 WHERE c2.comment_id = c1.comment_id order by comment_reply_id DESC limit 0,1) as reply_userid, 
        
        (SELECT c2.comment_reply FROM lv_comments_reply as c2 WHERE c2.comment_id = c1.comment_id order by comment_reply_id DESC limit 0,1) as reply_comment, 
        (SELECT c2.date_time FROM lv_comments_reply as c2 WHERE c2.comment_id = c1.comment_id order by comment_reply_id DESC limit 0,1) as reply_date_time, 
        (SELECT count(c2.comment_reply_id) FROM lv_comments_reply as c2 WHERE c2.comment_id = c1.comment_id order by comment_reply_id DESC limit 0,1) as reply_comments_count

        FROM `lv_comments` as c1  where c1.quick_lecture_id='$quick_lecture_id' order by c1.comment_id DESC $limit";
        $comments = $database->query($commentsquery)->fetchAll(PDO::FETCH_ASSOC);
		//echo "<pre>"; print_r($comments); 
        if($comments) {
              foreach ($comments as $k=>$comment) {
                $comments[$k]["UserData"] = get_user_data($comment['user_id']);
                if($comments[$k]["UserData"]!=""){
                  //$comments[$k]["UserData"]['is_friend'] = is_friend($user_id,$comment['user_id']);
                  $comments[$k]["UserData"]['is_blocked'] = is_blocked($user_id,$comment['user_id']);
                }else{
                  $comments[$k]["UserData"]="";
                }
                if($comment['reply_userid']!=""){
                  $comments[$k]["UserData_reply"] = get_user_data($comment['reply_userid']);
                  $comments[$k]["UserData_reply"]['is_blocked'] = is_blocked($user_id,$comment['reply_userid']);
                }else{
                  $comments[$k]["UserData_reply"] = "";
                  $comments[$k]["reply_comment"] = "";                  
                }
              }    
              $return_array = success("Success");
              $return_array["data"] = $comments;              
        }else{
              $return_array = failure("Error");
              $return_array["data"] = [];
        }
        return $return_array;
    }

/*
*
*Get Comment Reply
*
*/

 function reply_comments_list($parameters){
        $database = new medoo();
        $user_id = $parameters['user_id'];
        $comment_id = $parameters['comment_id'];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

        //$replyquery = "select comment_reply_id,user_id,comment_reply, date_time from lv_comments_reply where comment_id='$comment_id' order by comment_reply_id DESC $limit";
        $replyquery = "select * from lv_comments_reply where comment_id='$comment_id' order by comment_reply_id DESC $limit";
        $replies = $database->query($replyquery)->fetchAll(PDO::FETCH_ASSOC);
        if($replies) {
              foreach ($replies as $k=>$reply) {
                  $replies[$k]['UserData_reply'] = get_user_data($reply['user_id']);
                  //$replies[$k]['UserData_reply']['is_friend'] = is_friend($user_id,$reply['user_id']);
                  $replies[$k]["UserData_reply"]['is_blocked'] = is_blocked($user_id,$reply['user_id']);
              }
              $return_array = success("Success");
              $return_array["replies"] = $replies;              
        }else{
              $return_array = failure("Error");
              $return_array["replies"] = [];
        }
        return $return_array;
    }

/*
*
*Block Unblock user
*
*/


 function block_unblock_user($parameters){
          $actionn="";
          $database = new medoo();
          $return_array = array();
          $user_id = $parameters['user_id'];
          $blocked_user_id = $parameters['blocked_user_id'];
          if($parameters['action']==1){
              $last_user_id = $database->insert("lv_blocked_users", [
                'user_id' => $user_id,
                'blocked_user_id' => $blocked_user_id,
                "date" => date('Y-m-d H:i:s')
              ]);
              if($last_user_id){
                $return_array = success("User Blocked Successful");
                $actionn="blocked";
              }else{
                $return_array = Failure("Blocked Failed");
              }
          }else{
              $delete = $database->delete("lv_blocked_users",["AND" => ["blocked_user_id" => $blocked_user_id , "user_id" => $user_id ] ]);          
              if($delete){
                $return_array = success("User unblocked");
                $actionn="unblocked";
              }else{
                $return_array = Failure("Unblocked Failed.");
              }
          }
	 
	 
	 
	      $notified_user = get_user_data($blocked_user_id);
	      $receiver_user_id = get_user_data($user_id);
          $notified_user_details = get_user_data($blocked_user_id);

          
          if($data['user_id']!=$notified_user['user_id']){ 
            ###### save notifications #####
              $notif_msg = "Your Are $actionn by ".ucwords($notified_user_details['full_name']); 
              notify_user($notified_user['user_id'],$user_id,$notif_msg,$last_user_id,$actionn,'lv_users'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
            ###### save notifications #####
            ###### push notification ######
             
              if($notified_user['device_token']!=""){
                  $msgg['flag'] = "6";
                  $msgg['user_id'] = $receiver_user_id['user_id'];
                  $msgg['content_available'] = true;
                  $msgg['blocked_status'] = $actionn;
                  $msgg['msg'] = "Your Are $actionn by ".ucwords($receiver_user_id['full_name']); 
                  sendFcmeNotification($msgg,$notified_user['device_token']);
              }
            ###### push notification ######
          }
	 
	 

        return $return_array;
    }

/*
*
*
*Get all blocked users
*
*/



    function get_block_users($parameters){
        $database = new medoo();
        $user_id = $parameters['user_id'];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

        $usersquery = "select blocked_user_id from lv_blocked_users where status='1' and user_id='$user_id' order by id DESC $limit";
        $users = $database->query($usersquery)->fetchAll(PDO::FETCH_ASSOC);
        if($users) {
              foreach ($users as $k=>$user) {
                  $users[$k] = get_user_data($user['blocked_user_id']);
                  //$users[$k]['is_friend'] = is_friend($user_id,$user['blocked_user_id']);
              }
              $return_array = success("Success");
              $return_array["users"] = $users;              
        }else{
              //$return_array = failure("Error");
              $return_array = success("Success");
              $return_array["users"] = [];
        }
        return $return_array;
    }


/*
*
*
*Get all Notification
*
*/


	function get_notifications($parameters){
        $database = new medoo();
        $user_id = $parameters['user_id'];
        //$comment_id = $parameters['comment_id'];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

       $notif_query = "SELECT * FROM `lv_notifications` where `receiver_id` =  $user_id  order by id DESC $limit"; 
        $notif = $database->query($notif_query)->fetchAll(PDO::FETCH_ASSOC);
        if($notif) {
			foreach ($notif as $k=>$n) {
				$notif[$k]['Userdata'] = get_user_data($n['sender_id']);
				if($notif[$k]['Userdata']){
					$notif[$k]["Userdata"]['is_blocked'] = is_blocked($user_id,$n['sender_id']);
				}else{
					$notif[$k]['Userdata']="null";
				}
				$nid = $n['notify_id'];
				if($n['notify_id_table']=="lv_users"){
					$notif_sub_query = "SELECT * FROM `lv_users` where `user_id` =  $nid"; 
				}elseif($n['notify_id_table']=="lv_events"){
					$notif_sub_query = "SELECT * FROM `lv_events` where `event_id` =  $nid"; 
				}elseif($n['notify_id_table']=="lv_quick_lecture"){
					$notif_sub_query = "SELECT * FROM `lv_quick_lecture` where `quick_lecture_id` =  $nid"; 
				}
				
				$subdata = $database->query($notif_sub_query)->fetchAll(PDO::FETCH_ASSOC); 

				if($n['notify_id_table']=="lv_users"){
					$notif[$k]['users'] = $subdata[0];
				}elseif($n['notify_id_table']=="lv_events"){
					$notif[$k]['lecture_event'] = $subdata[0];
				}elseif($n['notify_id_table']=="lv_quick_lecture"){
					$notif[$k]['quick_lecture'] = $subdata[0];
					$notif[$k]['quick_lecture']['Userdata'] = get_user_data($subdata[0]['user_id']);
					$notif[$k]['quick_lecture'] =  array_merge($notif[$k]['quick_lecture'] , get_all_countsof_leacture($nid));
					$notif[$k]['quick_lecture']['is_liked'] = (string)is_liked($nid, $user_id);
					$notif[$k]['quick_lecture']['is_favourite'] = (string)is_favourite($nid, $user_id);
					$notif[$k]['quick_lecture']['is_reposted'] = check_is_reposted($user_id,$nid);
					$notif[$k]['quick_lecture']['reposted_lecture_id'] = check_is_reposted_lecture_id($user_id,$nid);
					
					
					
								$LID = $subdata['0']['quick_lecture_id'];
					   $GetparentLectureUserID = "SELECT `parent_lecture_user_id` from `lv_lecture_repost_status` where `quick_lecture_id` = '$LID' AND `user_id` = '$user_id'";
        $GetparentLectureUserID_main = $database->query($GetparentLectureUserID)->fetchAll(PDO::FETCH_ASSOC);
								$notif[$k]['quick_lecture']['OwnerUserdata'] = ($GetparentLectureUserID_main['0']['parent_lecture_user_id'] ? get_user_data($GetparentLectureUserID_main['0']['parent_lecture_user_id']) : NULL);						
								
					
					
				}
				//print_r($n['notify_id_table']);die("test");        
			}
			$return_array = success("Success");
			$return_array["notif"] = $notif;              
        }else{
              $return_array = failure("Error");
              $return_array["notif"] = [];
        }
        return $return_array;
    }






/***
 *
 *Update Device Details
 *
 **/

function update_device_details($parameters)
	{
			$database = new medoo();
       		$return_array = array();
			$device_token = $parameters['device_token'];
			$userid = $parameters['user_id'];
			$device_name = "'".$parameters['device_name']."'";
			$mac_address = "'".$parameters['mac_address']."'";
			$signal_strength = "'".$parameters['signal_strength']."'";
			$latitude = "'".$parameters['latitude']."'";
			$longitude = "'".$parameters['longitude']."'";
			$microphone = "'".$parameters['microphone']."'";
			//echo "<pre>"; print_r($parameters);
			$updateuserinfo = "update `lv_users` set `device_name` = $device_name , `mac_address` =  $mac_address, `signal_strength` = $signal_strength , `lat` = $latitude , `lang` = $longitude , `microphone` = $microphone  where  `user_id` = $userid";
		    $result = $database->query($updateuserinfo);
		
				//$update = $database->update("lv_quick_lecture", $data, [ "quick_lecture_id" => $quick_lecture_id ]);
		
		
			//echo $database->last_query(); die;
			
			if( $result )
				{
					$return_array = success("Device Details updated successfully");
					//$return_array['query'] = $updateuserinfo;
				}
		
			else{
				
					$return_array = failure("Failed");
					//$return_array['query'] = $updateuserinfo;
				    
               }
						
	return $return_array;	

		
	}


/**
 *
 * GET Search user by username or email
 *
 */
    function search_user($parameters){
        $return_array = array();
        $database = new medoo();
        $user_id = $parameters["user_id"];
								$user_idarray['user_id'] = $parameters["user_id"];
        $keyword = $parameters["keyword"];
        $page = $parameters["page"];
								
								//$checkfollow['target_user_id'] = $parameters['target_user_id'];
								$checkfollow['my_user_id'] = $parameters['user_id'];
		
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
		
        $query = "SELECT user_id FROM `lv_users` WHERE `user_id` != '".$user_id."' AND concat(full_name,email) like '%".$keyword."%' order by user_id desc $limit ";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        //echo $database->last_query(); die;
        //print_r($posts);die;
        if($posts) {
              foreach ($posts as $k=>$post) {
															$checkfollow = '';
                $all_data[] = get_user_data($post['user_id']);
                //$all_data[$k]['is_friend'] = is_friend($user_id,$post['user_id']);
                $all_data[$k]['is_blocked'] = is_blocked($user_id,$post['user_id']);
																//$all_data[$k]['is_follower'] = get_my_followers($user_idarray);
																
																						$checkfollow['target_user_id'] = $post['user_id'];
																						$checkfollow['my_user_id'] = $parameters['user_id'];
																
																						$follow = 	get_user_profile($checkfollow);
																						
																						//echo "<pre>";print_r($follow);
																						//echo $follow['data']['Userdata']['Is_following'];
																											
																//$all_data[$k]['Userdata'] = get_user_data($post['user_id']);				   	
																$all_data[$k]['is_following'] = $follow['data']['Userdata']['Is_following'];
              }
              $return_array = success("Search results");
              $return_array["data"] = $all_data;
        }else{
              $all_data = array();
              $return_array = failure("No data found");
              $return_array["data"] = $all_data;
        }
        //print_r($return_array);die;

        return $return_array;
    }



/*
*
*Get User data by id
*
*/


  function get_single_user($userID){
	$userID = $userID['user_id'];
    $database = new medoo();   
    
    /*$select_user = "SELECT `microphone`,`device_name`, `mac_address`, `signal_strength` ,`cover_pic`,`user_id`,`role_id`,`full_name`,`email`,`device_type`,`device_token`,`register_via`,`social_id`,`profile_pic`,`login_status`,`location`,`lat`,`lang`,`website`,`bio` FROM `lv_users` WHERE `user_id`='$userID'";
    $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);	
	$return_array = success("Single user details");
	$return_array["data"] = $result['0'];
	$return_array['Userdata'] = get_user_data($userID);*/
	//$return_array['event_interest'] = get_lecture_orevent_interest(get_eventid_by_user_id($userID));
	$return_array = success("Single user details");
	$return_array["data"] = get_user_data($userID);
	return $return_array;     
  }



/*
*
*Search Near by host 
*
*/


  function get_nearby_co_hosts($parameters){
	  $latitude = $parameters['latitude'];
	  $longitude = $parameters['longitude'];
	  $page = $parameters['page'];
	  $distance = $parameters['distance'];
     $database = new medoo();   
	  
	  
	  
	    if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
	  
    $select_user = "SELECT * , (3956 * 2 * ASIN(SQRT( POWER(SIN(( $latitude - lat) *  pi()/180 / 2), 2) +COS( $latitude * pi()/180) * COS(lat * pi()/180) * POWER(SIN(( $longitude - lang) * pi()/180 / 2), 2) ))) as distance  
from lv_users  
having  distance <= $distance 
order by distance $limit";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
	
	  $return_array = success("Single user details");
      $return_array["data"] = $result;
	  
      return $return_array;     
  }






 /**
 *
 * Event Attend And Interest
 *
 */
    function event_attend_and_interest($parameters){
        $return_array = array();
        $database = new medoo();
		
        $data['event_id'] = $parameters["event_id"];
        $data['user_id'] = $parameters["user_id"]; 
		
		$actionn = $parameters["action"]; // attend or interst
		
        if($actionn == 'attend'){
			
			$data['attend_type'] = $parameters["attend_type"];
			
			$update = "`attend_type` = '".$parameters["attend_type"]."'";
			
			$message = "Attend " . $parameters["attend_type"];
		}        
		
        if($actionn == 'interest'){
			
			$data['is_interested'] = $parameters["is_interested"];
			
			if($parameters["is_interested"] === 'false')
			{
			
					$update = "`is_interested` = '".$parameters["is_interested"]."' , `attend_type` = '".$parameters["attend_type"]."'";
			
			}
			
			else{
				$update = "`is_interested` = '".$parameters["is_interested"]."'";
			}
			
			$message = "Added to his interest ";
		}      
		
        $data["date_time"] = utc_date();
		
		
        $event_id = $parameters["event_id"];
        $userid = $parameters["user_id"];
		
        $query = "select count(*) as cnt from lv_event_attend_and_interest where event_id='".$data['event_id']."' and user_id='".$data['user_id']."'";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        if($posts[0]['cnt']==0) {
			
			
              $insert = $database->insert("lv_event_attend_and_interest", $data);
              $return_array = success("User Event Detail updated successfully");
              $return_array["like_id"] = $data;
              
        }else{ 
			
			$updateusereventinfo = "update `lv_event_attend_and_interest` set $update  where  `user_id` = $userid AND `event_id` = $event_id";
		    $updateusereventinforesult = $database->query($updateusereventinfo);
			
              $return_array = success("User Event Detail updated successfully");
              $return_array["like_id"] = $data;
              
        }

        if($actionn=="attend" || $actionn=="interst"){
			
          $notified_user = get_event_user_details($event_id);
          $notified_user_details = get_user_name_by_id($userid);

         
          if($data['user_id']!=$notified_user['user_id']){ 
            ###### save notifications #####
              $notif_msg = "Your Event (".$notified_user['lecture_title'].") is $message by ".ucwords($notified_user_details['full_name']); 
              notify_user($notified_user['user_id'],$userid,$notif_msg,$event_id,$actionn,'lv_events'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
            ###### save notifications #####
            ###### push notification ######
             
              if($notified_user['device_token']!=""){
                  $msgg['flag'] = "7";
                  $msgg['user_id'] = $notified_user['user_id'];
                  $msgg['event_id'] = $data['event_id'];
                  $msgg['msg'] = "Your Event (".$notified_user['lecture_title'].") is $message by ".ucwords($notified_user_details['full_name']); 
                  sendFcmeNotification($msgg,$notified_user['device_token']);
              }
            ###### push notification ######
          }
			
			
			
			
        }
		//$return_array['query'] = $updateusereventinfo;

        return $return_array;
    }








/**
 *
 *Send Event Invitations
 *
 **/

	function send_event_invitation($parameters){
		
				$return_array = array();
				$database = new medoo();
				$data = array();
				
					
				$userid = $parameters["sender_id"];
		  $event_id = $parameters["event_id"];
		
				$senderids = explode(',' , $parameters["receiver_id"]);
		        
						
				foreach($senderids as $countsmain)
				{ //echo $countsmain;
				$data = '';
					//echo $countsmain; die;
					$data['sender_id'] = $parameters["sender_id"];
					$data['receiver_id'] = $countsmain;	
					$data['event_id'] = $parameters["event_id"];
					
					$SendEventInvitation = $database->insert("lv_event_invitation" , $data);
					
					
					
							  $actionn ='event_invitation';
							  $notified_user = get_event_user_details($event_id);
							  $notified_user_details = get_user_name_by_id($userid);
           
         
						  if($userid!=$notified_user['user_id']){ 
							###### save notifications #####
							  $notif_msg = "Your have recieve invitation for event (".$notified_user['lecture_title'].") from ".ucwords($notified_user_details['full_name']); 
							  notify_user($countsmain,$userid,$notif_msg,$event_id,$actionn,'lv_events'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
							###### save notifications #####
							###### push notification ######

							  if($notified_user['device_token']!=""){
								  $msgg['flag'] = "8";
								  $msgg['user_id'] = $notified_user['user_id'];
								  $msgg['event_id'] = $data['event_id'];
								  $msgg['msg'] = "Your have recieve invitation for event (".$notified_user['lecture_title'].") from ".ucwords($notified_user_details['full_name']); 
								  sendFcmeNotification($msgg,$notified_user['device_token']);
							  }
							###### push notification ######
						  }
					
				
				}
	
		        		 		
                	
		
		if($SendEventInvitation)
			{
					
					$return_array = success("Invitation sent successfully");
					$return_array['date'] = $data;
							
				
			}	
		else{
					$return_array = failure("Error Inserting event invitation");
					$return_array['date'] =  $data;
		
		    }
					
				return $return_array;
		
	}




/*
*
*Get Event Invitations 
*
*/


  function get_event_invitation($parameters){
	  
	       $database = new medoo(); 

	  $page = $parameters['page'];
	 $userID= $parameters["user_id"]; // reciever id	
  
	  
	  
	  
	    if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
	  
     $select_user = "SELECT * FROM `lv_event_invitation` where `receiver_id` = $userID order by `date_time` $limit";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
	  
	  	foreach($result as $key => $resultmain)
		{
		    $a['event_id'] = $resultmain['event_id'];			
		    $a['hideresponce'] = 'true';
					

		    $responce[] =  get_single_lecture_event($a);
			
			$GetCoHostsID = explode(',' , $responce[$key]['lecturer_co_hosts']);
					
					//print_r($GetCoHostsID);

					$Get_Users_Data_CoHosts = array();
					foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
					{
						$getUsaeDate = '';				
						$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
						$getUsaeDate =  get_user_data($int);
						 if($getUsaeDate)
						 {
						 	$Get_Users_Data_CoHosts[] = $getUsaeDate;
						 }
				
					}
					
					$responce[$key]['Userdata'] = get_user_data(get_userid_by_event_id($resultmain['event_id']));				   	
					$responce[$key]['event_interest'] = get_lecture_orevent_interest($resultmain['event_id'],'event');
					$responce[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
		
		}

	   // echo "<pre>"; print_r($responce);
	    
	  $return_array = success("Invitations list");
      $return_array["data"] = $responce;
	  
      return $return_array;     
  }




/*
*
*Get Event Co Hosts 
*
*/


  function get_my_hosting_list($parameters){
	  
	       $database = new medoo(); 

	  $page = $parameters['page'];
	 $userID= $parameters["user_id"]; // reciever id	
  
	  
	  
	  
	    if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
	  
     //$select_user = "select * from lv_events where find_in_set($userID,lecturer_co_hosts) order by `lecture_start_date_time` $limit";
     $select_user = "select `event_id` , `lecturer_co_hosts` from lv_events where user_id = $userID order by `lecture_start_date_time` $limit";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
     //print_r($result);die;

	  if($result)
	  {
		  	foreach($result as $key => $resultmain)
				{
					$a['event_id'] = $resultmain['event_id'];			
					$a['hideresponce'] = 'true';			
					$responce[] =  get_single_lecture_event($a);
					
					$GetCoHostsID = explode(',' , $resultmain['lecturer_co_hosts']);

					
					$Get_Users_Data_CoHosts = array();
					foreach($GetCoHostsID as $ke => $GetCoHostsIDMain)
					{
						$getUsaeDate = '';				
						$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
						$getUsaeDate =  get_user_data($int);
						 if($getUsaeDate)
						 {
						 	$Get_Users_Data_CoHosts[] = $getUsaeDate;
						 }
					}
					
					$responce[$key]['Userdata'] = get_user_data($userID);				   	
					$responce[$key]['event_interest'] = get_lecture_orevent_interest($resultmain['event_id'],'event');
					$responce[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );

				}

		  
	  	$return_array = success("my co host details");
      	$return_array["data"] = $responce;
	  }
	  else{
	  	  	$return_array = failure("list not found");
      	    $return_array["data"] = [];
	  }
	  
	  
      return $return_array;     
  }




/**
 *
 * GET Search Lecture veents
 *
 */

    function search_lecture_event($parameters){
        $return_array = array();
        $database = new medoo();
        //$user_id = $parameters["user_id"];
        $keyword = $parameters["keyword"];
        $page = $parameters["page"];
		
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
		
        $query = "SELECT * FROM `lv_events` WHERE lecture_title like '%".$keyword."%' order by lecture_start_date_time desc $limit ";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        //echo $database->last_query(); die;
        if($posts) {
																		
				foreach($posts as $key => $GetLectureEventMainValue){
		
					$lectureevents[$key] = $GetLectureEventMainValue;
				   	$lectureevents[$key]['Userdata'] = get_user_data($GetLectureEventMainValue['user_id']);				   	
				   	$lectureevents[$key]['event_interest'] = get_lecture_orevent_interest($GetLectureEventMainValue['event_id'],'event');
					$lectureevents[$key]['Isinterested'] = check_event_attend_and_interest($GetLectureEventMainValue['user_id'] ,  $GetLectureEventMainValue['event_id']);
					$lectureevents[$key]['Isinvited'] = invited($GetLectureEventMainValue['user_id'] ,  $GetLectureEventMainValue['event_id']);
				
					$GetCoHostsID = explode(',' , $GetLectureEventMainValue['lecturer_co_hosts']);
				
					foreach($GetCoHostsID as $ke => $GetCoHostsIDMain){
						$getUsaeDate = '';				
						$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
						$getUsaeDate =  get_user_data($int);
						if($getUsaeDate){
							$Get_Users_Data_CoHosts[] = $getUsaeDate;
						}
					}		
					$lectureevents[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );
						
				}

									//echo "<pre>"; print_r($lectureevents); die('aasasas');
              $return_array = success("Search results");
              $return_array["data"] = $lectureevents;
        }else{
              $all_data = array();
              $return_array = failure("No data found");
              $return_array["data"] = $all_data;
        }

        return $return_array;
    }




 /**
 *
 * Share Lecture OR Events
 *
 */
    function share($parameters){
        $return_array = array();
        $database = new medoo();
        $data['shared_id'] = $parameters["shared_id"];
        $data['user_id'] = $parameters["user_id"];
								$data['share_type'] = $parameters['share_type'];  
        $data["date_time"] = utc_date();
        $quick_lecture_id = $parameters["shared_id"];
        $userid = $parameters["user_id"];
								$share_type = $parameters['share_type']; 
        $query = "select count(*) as cnt from lv_share where shared_id='".$data['shared_id']."' and user_id='".$data['user_id']."' and share_type = '".$data['share_type']."' ";
        $posts = $database->query($query)->fetchAll(PDO::FETCH_ASSOC);
        if($posts[0]['cnt']==0) {
              $insert = $database->insert("lv_share", $data);
              $return_array = success("share successfully");
              $return_array["share_id"] = $insert;
              $actionn = "share";
        }else{
             // $database->delete("lv_share",["AND" => ["shared_id" => $quick_lecture_id , "user_id" => $userid ] ]);
              $return_array = success("Already shared");
              $return_array["share_id"] = [];
              $actionn = "alreadyshare";
        }
								
								        if($actionn == "share"){
																	
																						if($share_type === 'event' )
																						{
																								$notified_user = get_event_user_details($quick_lecture_id);
																								$title = $notified_user['lecture_title'];
																								$notif_table = "lv_events";
																						}
																						
																						else
																						{																								
																								$notified_user = get_quick_lecture_user_details($quick_lecture_id);
																				 			$title = 	$notified_user['quick_lecture_text'];
																				 			$notif_table = "lv_quick_lecture";
																						}
																				
          $notified_user_details = get_user_name_by_id($userid);

          //echo $data['user_id'] ." === ".$notified_user['user_id'] ;  die;
          if($data['user_id']!=$notified_user['user_id']){
            ###### save notifications #####
              $notif_msg = "Your $share_type (".$title.") is $actionn by ".ucwords($notified_user_details['full_name']); 
              notify_user($notified_user['user_id'],$userid,$notif_msg,$quick_lecture_id,$actionn,$notif_table); // reciever_id, sender_id, msg, quick_lecture_id(optional)
            ###### save notifications #####
            ###### push notification ######
             
              if($notified_user['device_token']!=""){
                  $msgg['flag'] = "3";
                  $msgg['user_id'] = $notified_user['user_id'];
                  $msgg['quick_lecture_id'] = $data['quick_lecture_id'];
                  $msgg['msg'] = "Your $share_type (".$notified_user['quick_lecture_text'].") is $actionn by ".ucwords($notified_user_details['full_name']); 
                  sendFcmeNotification($msgg,$notified_user['device_token']);
              }
            ###### push notification ######
          }
						
        }

        return $return_array;
								

				}



/*
*
*Get Share lecture and events
*
*/


  function get_share_list($parameters){
	  
	    $database = new medoo();
	  	$page = $parameters['page'];
		$share_type = $parameters['share_type'];
	  	$userID= $parameters["user_id"]; // reciever id	  
	    if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;
	  
		$select_user = "SELECT * FROM `lv_share` where `user_id` = $userID AND `share_type` = '$share_type' order by `date_time` $limit";
		$result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
		//echo "<pre>"; print_r($result); die;
		if($share_type === 'event' ){
  			foreach($result as $key => $resultmain){
				$a['event_id'] = $resultmain['shared_id'];
				$a['user_id'] = $userID;	
				$a['hideresponce'] = 'true';			
				$responce[] =  get_single_lecture_event($a);				
				$GetCoHostsID = explode(',' , $responce[$key]['lecturer_co_hosts']);						
				//print_r($GetCoHostsID);
				foreach($GetCoHostsID as $ke => $GetCoHostsIDMain){
					$getUsaeDate = '';				
					$int = intval(preg_replace('/[^0-9]+/', '', $GetCoHostsIDMain), 10);
					$getUsaeDate =  get_user_data($int);
					if($getUsaeDate){
						$Get_Users_Data_CoHosts[] = $getUsaeDate;
					}										
				}					
				$responce[$key]['lecturer_co_hosts'] = ($Get_Users_Data_CoHosts ? $Get_Users_Data_CoHosts : [] );			
			}
		}else{				  
		  	foreach($result as $key => $resultmain){ 
				$parameters["quick_lecture_id"] = $resultmain['shared_id'];
				//$responce = $result;
				$getlecture =  get_lectures_by_id($parameters);
				$responce[$key] = $getlecture['0'];


				$responce[$key] = array_merge($responce[$key] , get_all_countsof_leacture($responce[$key]['quick_lecture_id']));
				$responce[$key]['is_liked'] = (string)is_liked($responce[$key]['quick_lecture_id'], $userID);
				$responce[$key]['is_favourite'] = (string)is_favourite($responce[$key]['quick_lecture_id'], $userID);
				$responce[$key]['is_reposted'] = check_is_reposted($userID,$responce[$key]['quick_lecture_id']);



				$responce[$key]['Userdata'] =  get_user_data($resultmain['user_id']);
			}	
		}
	    //echo "<pre>"; print_r($responce); die;	    
		$return_array = success("Share list");
		$return_array["data"] = $responce;
		return $return_array;     
  }


/*
*
*get Get cat and sub cat
*
*/
  
   	function get_categories(){
    	$database = new medoo();
		$get_vategories = "SELECT * FROM `lv_categories` WHERE parent_id='0'"; 
		$result_get_vategories = $database->query($get_vategories)->fetchAll(PDO::FETCH_ASSOC);      
		$return_array = success("categories list");
		foreach($result_get_vategories as $key => $arr){
			$get_sub_cat = "SELECT * FROM `lv_categories` WHERE parent_id='".$arr['id']."'"; 
	    	$result_get_sub_cat = $database->query($get_sub_cat)->fetchAll(PDO::FETCH_ASSOC);
	    	$result_get_vategories[$key]['child'] = $result_get_sub_cat;
	    }
	    $return_array = success("categories list");
	    $return_array["data"] = $result_get_vategories;
      	return $return_array;
  	}


/*
*
*save users interest
*
*/
  
   function save_users_interest( $parameters ){
			$database = new medoo();
		 $catids = $parameters['category_id'];
			$user_id = $parameters['user_id'];
	
			$explode = explode(',' , $catids);
	
			$database->delete("lv_users_interest",["AND" => ["user_id" => $user_id ] ]);
			foreach($explode as $explodeval){
				$insertdata = '';
			    $insertdata['category_id'] = $explodeval;
				$insertdata['user_id'] = $user_id;
				/*$check = $database->query("SELECT count(*) as count  FROM lv_users_interest where user_id =$user_id AND category_id =$explodeval ")->fetchAll(PDO::FETCH_ASSOC);

				if($check['0']['count'] == 0)
				{*/
				$result_get_vategories = $database->insert("lv_users_interest" , $insertdata);
				//}												
						
			}
      
      
      
	$return_array = success("Your Interest categories are saved successfully.");	
    return $return_array;
  }



/*
*
*save lecture and event interest
*
*/
  
   function save_lecture_or_event_interest( $parameters ){
						$database = new medoo();
					 $catids = $parameters['category_id'];
						$user_id = $parameters['user_id'];
						$interest_id = $parameters['interest_id'];
						$interest_type = $parameters['interest_type'];
					
						$explode = explode(',' , $catids);
						$database->delete("lv_lecture_or_event_interests",["AND" => ["interest_id" => $interest_id , "interest_type" => $interest_type ] ]);
						foreach($explode as $explodeval)
							{ $insertdata = '';
								    $insertdata['category_id'] = $explodeval;
										 	$insertdata['user_id'] = $user_id;
												$insertdata['interest_id'] = $parameters['interest_id'];
												$insertdata1 = $parameters['interest_type'];
												$insertdata['interest_type'] = "$insertdata1";
												
												/*$check = $database->query("SELECT count(*) as count  FROM lv_lecture_or_event_interests where user_id =$user_id AND category_id =$explodeval and interest_id =$interest_id and interest_type= '$interest_type'")->fetchAll(PDO::FETCH_ASSOC);*/
			
												
													
												//if($check['0']['count'] == 0){
													$result_get_vategories = $database->insert("lv_lecture_or_event_interests" , $insertdata);	
												//}
										
							}
      
						$return_array = success("Category added Successfully.");	
      return $return_array;
  }


/*
*
*get_suggested_lectures
*
*/
	function get_suggested_lectures($parameters){
		
		$return_array = array();
		$database = new medoo();
		$user_id = $parameters["user_id"];

 			$get_lectures1 = "SELECT ql.* FROM `lv_users_interest` ui JOIN `lv_quick_lecture` ql ON ui.category_id=ql.category_id WHERE ui.user_id='".$user_id."'  and ql.user_id!='".$user_id."' Limit 50";
        	$get_lectures_query1 = $database->query($get_lectures1)->fetchAll(PDO::FETCH_ASSOC);

 			$get_lectures2 = "SELECT (COUNT(fl.quick_lecture_id) + ql.lecture_view) as sumdata, ql.* FROM `lv_favourite_list` fl JOIN lv_quick_lecture ql ON fl.quick_lecture_id = ql.quick_lecture_id WHERE fl.user_id!='".$user_id."' GROUP BY fl.quick_lecture_id ORDER BY sumdata DESC Limit 50";
        	$get_lectures_query2 = $database->query($get_lectures2)->fetchAll(PDO::FETCH_ASSOC);

 			$get_lectures3 = "SELECT * FROM `lv_quick_lecture` WHERE user_id!='".$user_id."' ORDER BY `quick_lecture_id` DESC Limit 50";
        	$get_lectures_query3 = $database->query($get_lectures3)->fetchAll(PDO::FETCH_ASSOC);

			foreach($get_lectures_query1 as $key => $get_lectures_value1){
				$lecture_array1[$key] = array_merge($get_lectures_value1 , get_all_countsof_leacture($get_lectures_value1['quick_lecture_id']));
				$lecture_array1[$key]['is_liked'] = (string)is_liked($get_lectures_value1['quick_lecture_id'], $user_id);
				$lecture_array1[$key]['is_favourite'] = (string)is_favourite($get_lectures_value1['quick_lecture_id'], $user_id);
				$lecture_array1[$key]['Userdata'] = get_user_data($get_lectures_value1['user_id']);

				$lecture_array1[$key]['is_reposted'] = check_is_reposted($user_id,$get_lectures_value1['quick_lecture_id']);
			}

			foreach($get_lectures_query2 as $key1 => $get_lectures_value2){
				$lecture_array2[$key1] = array_merge($get_lectures_value2 , get_all_countsof_leacture($get_lectures_value2['quick_lecture_id']));
				$lecture_array2[$key1]['is_liked'] = (string)is_liked($get_lectures_value2['quick_lecture_id'], $user_id);
				$lecture_array2[$key1]['is_favourite'] = (string)is_favourite($get_lectures_value2['quick_lecture_id'], $user_id);
				$lecture_array2[$key1]['Userdata'] = get_user_data($get_lectures_value2['user_id']);
				$lecture_array2[$key1]['is_reposted'] = check_is_reposted($user_id,$get_lectures_value2['quick_lecture_id']);
			}

			foreach($get_lectures_query3 as $key2 => $get_lectures_value3){
				$lecture_array3[$key2] = array_merge($get_lectures_value3 , get_all_countsof_leacture($get_lectures_value3['quick_lecture_id']));
				$lecture_array3[$key2]['is_liked'] = (string)is_liked($get_lectures_value3['quick_lecture_id'], $user_id);
				$lecture_array3[$key2]['is_favourite'] = (string)is_favourite($get_lectures_value3['quick_lecture_id'], $user_id);
				$lecture_array3[$key2]['Userdata'] = get_user_data($get_lectures_value3['user_id']);
				$lecture_array3[$key2]['is_reposted'] = check_is_reposted($user_id,$get_lectures_value3['quick_lecture_id']);
			}
			$return_array = success("List of lectures.");
			$return_array['data']['suggested']  = $lecture_array1;
			$return_array['data']['hot']  = $lecture_array2;
			$return_array['data']['top']  = $lecture_array3;

		return $return_array;
	}



/*
*
*REPOST A LECTURE
*
*/
	function repost_lecture($parameters){
		
		$return_array = array();
		$data = array();
		$database = new medoo();
		$user_id = $parameters["user_id"];
		$quick_lecture_id = $parameters["quick_lecture_id"];
		
		$lecture_qry = "SELECT * FROM `lv_quick_lecture` WHERE quick_lecture_id='".$quick_lecture_id."'";
        $lecture_data = $database->query($lecture_qry)->fetchAll(PDO::FETCH_ASSOC);

		   //$get_lectures = "INSERT INTO lv_quick_lecture (`user_id`, `category_id`, `quick_lecture_type`, `file_path`, `quick_lecture_text`, `thumbnail`, `discovery_url`, `privacy`, `lecture_view`,`quick_lecture_time_duration`, `date_time`) SELECT '".$user_id."', `category_id`, `quick_lecture_type`, `file_path`, `quick_lecture_text`, `thumbnail`, `discovery_url`, `privacy`, `lecture_view`, `quick_lecture_time_duration`,'".utc_date()."' FROM lv_quick_lecture WHERE quick_lecture_id='".$quick_lecture_id."'";
    	//$get_lectures_query = $database->query($get_lectures);
    	//$up_lecture_id = $database->pdo->lastInsertId();
					$parentuserid = $lecture_data[0]['user_id'];

    	$data['user_id'] = $user_id;
    	$data['quick_lecture_id'] = $quick_lecture_id;
    	$data['date_time'] = utc_date();
					$data['parent_lecture_user_id'] = $parentuserid;
					//$data['reposted_id'] = $quick_lecture_id;
					
                    
     $last_user_id = $database->insert("lv_lecture_repost_status",$data);  

    	/*$get_lectures_repost = "INSERT INTO lv_lecture_repost_status (`user_id`, `quick_lecture_id`,`parent_lecture_user_id`,`reposted_id`, `date_time`) SELECT `user_id`,'".$up_lecture_id."', '".$parentuserid."' , '".$up_lecture_id."' ,'".utc_date()."' FROM lv_lecture_repost_status WHERE quick_lecture_id='".$quick_lecture_id."'";
    	$get_lectures_repost_query = $database->query($get_lectures_repost);*/

    	$get_lectures_fav = "INSERT INTO lv_favourite_list (`quick_lecture_id`, `user_id`, `is_favourite`, `date_time`) SELECT '".$quick_lecture_id."','".$user_id."',`is_favourite`, '".utc_date()."' FROM lv_favourite_list WHERE quick_lecture_id='".$quick_lecture_id."'";
    	$get_lectures_fav_query = $database->query($get_lectures_fav); 

            $owner_user_data = get_user_data($parentuserid);
            $sender_user_name = get_user_name_by_id($data['user_id'] );
                            $utc_time = utc_date();
							$updatedeletestatus = "update `lv_quick_lecture` set `reposted_date_time` = '$utc_time'   where  `quick_lecture_id` = $quick_lecture_id" ;
                            //echo $updatedeletestatus;die;
								$result22 = $database->query($updatedeletestatus);

        ###### save notifications #####
        	$notif_msg = "Your Lecture (".$lecture_data[0]['quick_lecture_text'].") is reposted by ".$sender_user_name['full_name']; 
          	notify_user($lecture_data[0]['user_id'],$user_id,$notif_msg,$quick_lecture_id,'reposted','lv_quick_lecture'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
        ###### save notifications #####     	

		$return_array = success("Lecture reposted successfully.");
           
            ###### push notification ######
              if($owner_user_data['device_token']!=""){
                  $msgg['flag'] = "14";
                  $msgg['user_id'] = $user_id;
                  $msgg['content_available'] = true;
                  $msgg['quick_lecture_id'] = $parameters["quick_lecture_id"];
                  $msgg['msg'] = $notif_msg; 
                  sendFcmeNotification($msgg,$owner_user_data['device_token']);
              }
		return $return_array;
	}
	
	
	
	
	
	function unrepost_lecture($parameters){ 
								$return_array = array();
								$data = array();
								$database = new medoo();

                                ##### getting parent lecture data  to get user_id #####
                                $lecture_qry = "SELECT * FROM `lv_lecture_repost_status` WHERE quick_lecture_id='".$parameters['quick_lecture_id']."' AND user_id='".$parameters['user_id']."' ";
                                $lecture_data = $database->query($lecture_qry)->fetchAll(PDO::FETCH_ASSOC);
                                $parentuserid = $lecture_data[0]['parent_lecture_user_id'];
                                
                                ##### getting parent lecture name from quick lecture table to append lecture name in notification message #######
                                $quick_lecture_qry = "SELECT quick_lecture_text FROM `lv_quick_lecture` WHERE quick_lecture_id='".$parameters['quick_lecture_id']."'";
                                $quick_lecture_data = $database->query($quick_lecture_qry)->fetchAll(PDO::FETCH_ASSOC);
                                $lecture_name = $quick_lecture_data[0]['quick_lecture_text'];
                                
                                ###### getting user's data to generate notification #####
                                $owner_user_data = get_user_data($parentuserid);
                                $sender_user_data = get_user_data($parameters['user_id']);
            
                                ##### deleting entry from table to unrepost the lecture######
                                $database->delete("lv_lecture_repost_status",["AND" => ["quick_lecture_id" => $parameters['quick_lecture_id'] , "user_id" => $parameters['user_id'] ] ]);
								$database->delete("lv_quick_lecture",["AND" => ["quick_lecture_id" => $parameters['quick_lecture_id'] , "user_id" => $parameters['user_id'] ] ]);
								$return_array = success("Un-Reposted successfully");
            
            $notif_msg = "Your lecture (".$lecture_name.") is un re-posted by ".$sender_user_data['full_name'];
            
            ###### push notification ######
              if($owner_user_data['device_token']!=""){
                  $msgg['flag'] = "15";
                  $msgg['user_id'] = $sender_user_data['user_id'];
                  $msgg['content_available'] = true;
                  $msgg['quick_lecture_id'] = $lecture_data[0]['quick_lecture_id'];
                  $msgg['msg'] = $notif_msg; 
                  sendFcmeNotification($msgg,$owner_user_data['device_token']);
              }
                                
			return $return_array;
		
	}

/*
 *
 * List of users who reposted a lecture
 *
 */
	function repost_lecture_users_list($parameters){
		
		$return_array = array();
		$database = new medoo();
		$quick_lecture_id = $parameters["quick_lecture_id"];

	  	$page = $parameters['page'];
	    if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

        $userslist = "SELECT u.* FROM `lv_lecture_repost_status` lps JOIN `lv_users` u on lps.user_id=u.user_id WHERE lps.`quick_lecture_id`='".$quick_lecture_id."' $limit";
        $userslist_data = $database->query($userslist)->fetchAll(PDO::FETCH_ASSOC);
		
		/*if($userslist_data){
			foreach($userslist_data as $key => $userslist_val){

			}
		}*/

		$return_array = success("List of Users.");
		$return_array['data']  = $userslist_data;

		return $return_array;
	}
	
/*
 *
 * Follow a user
 *
 */
	function follow_user($parameters){
		$notificationFlag = "";
		$return_array = array();
		$database = new medoo();
		$data['follower_user_id'] = $parameters["follower_user_id"];
		$data['followed_user_id'] = $parameters["followed_user_id"];
		$data['date_time'] = utc_date();
		$follow_query = "SELECT count(*) as cnt FROM `lv_followers` WHERE follower_user_id='".$data['follower_user_id']."' and followed_user_id='".$data['followed_user_id']."'";
	    $follow_data = $database->query($follow_query)->fetchAll(PDO::FETCH_ASSOC);
		if($follow_data[0]['cnt'] > 0){
			$database->delete("lv_followers",["AND" => ["follower_user_id" => $data['follower_user_id'] , "followed_user_id" => $data['followed_user_id'] ] ]);
			$return_array = success("Unfollowed successfully");
            $notificationFlag = "13";
		}else{
			$last_user_id = $database->insert("lv_followers",$data);
			if( $last_user_id ){
				$return_array = success("Following now");
                $notificationFlag = "12";
			}else{
				$return_array = failure("Failed");
			}
		}

        $follower_user = get_user_data($data['follower_user_id']);
          $followed_user = get_user_data($data['followed_user_id']);
          
          if($follower_user['user_id']!=$followed_user['user_id']){
            ###### save notifications #####
              $notif_msg = $follower_user['full_name']. (($notificationFlag == '12') ? " has started following you." : " has unfollowed you.");
              //if($notificationFlag == '12')
              //{
              notify_user($followed_user['user_id'],$follower_user['user_id'],$notif_msg,$follower_user['user_id'],($notificationFlag == '12') ? "follow" : "unfollow",'lv_users'); // reciever_id, sender_id, msg, quick_lecture_id(optional)
              //}              
            ###### save notifications #####
            ###### push notification ######
              if($followed_user['device_token']!=""){
                  $msgg['flag'] = $notificationFlag;
                  $msgg['user_id'] = $follower_user['user_id'];
                  $msgg['msg'] = $notif_msg; 
                  sendFcmeNotification($msgg,$followed_user['device_token']);
          }
          }

		return $return_array;
	}

	function get_my_followers($parameters){		
		$return_array = array();
		$database = new medoo();
		$user_id= $parameters["user_id"];
		$follow_query = "SELECT CASE WHEN (SELECT followed_user_id from lv_followers where followed_user_id=f.follower_user_id and follower_user_id='".$user_id."') IS NOT NULL  THEN 1 ELSE 0 END AS is_following, u.* FROM `lv_followers` f JOIN lv_users u on f.follower_user_id=u.user_id WHERE f.followed_user_id='".$user_id."'";
	    $follow_data = $database->query($follow_query)->fetchAll(PDO::FETCH_ASSOC);		
		if($follow_data) {
              $return_array = success("My followers list");
              $return_array["data"] = $follow_data;
        }else{
              $all_data = array();
              $return_array = failure("No follower found");
              $return_array["data"] = $all_data;
        }
		return $return_array;
	}

	function get_my_followings($parameters){ //is_following = 'true'
		
		$return_array = array();
		$database = new medoo();
		$user_id= $parameters["user_id"];
		$follow_query = "SELECT '1' as is_following, u.* FROM `lv_followers` f JOIN lv_users u on f.followed_user_id=u.user_id WHERE f.follower_user_id='".$user_id."'";
	    $follow_data = $database->query($follow_query)->fetchAll(PDO::FETCH_ASSOC);		
		if($follow_data) {
              $return_array = success("Followed users list");
              $return_array["data"] = $follow_data;
        }else{
              $all_data = array();
              $return_array = failure("No user found");
              $return_array["data"] = $all_data;
        }
		return $return_array;
	}

	function people_you_may_know($parameters){ //is_following = 'false'
		
		$return_array = array();
		$database = new medoo();
		$user_id= $parameters["user_id"];
		//$follow_query = "SELECT  '0' as is_following, u.* from lv_followers f JOIN lv_followers ff on f.follower_user_id=ff.followed_user_id JOIN lv_users u on ff.follower_user_id=u.user_id where f.followed_user_id='".$user_id."' AND ff.follower_user_id!='".$user_id."' group by u.user_id";
		
	$follow_query = 	"select '0' as is_following, lv_users.* from lv_users where user_id not in (select followed_user_id from lv_followers where follower_user_id='".$user_id."') and user_id!='".$user_id."'";
	    $follow_data = $database->query($follow_query)->fetchAll(PDO::FETCH_ASSOC);	
		if (count($follow_data) > 0){
		      $return_array = success("Followed users list");
              $return_array["data"] = $follow_data;
	    }else{
	    	$follow_query = "SELECT '0' as is_following, u.* from lv_users u where u.user_id not in (select uu.user_id from lv_users uu join lv_followers ff on ff.followed_user_id='".$user_id."' where uu.user_id=ff.follower_user_id) AND u.user_id!='".$user_id."'";
	    	$follow_data = $database->query($follow_query)->fetchAll(PDO::FETCH_ASSOC);	
	    	$return_array = success("Followed users list");
            $return_array["data"] = $follow_data;
	    }
		return $return_array;
	}
	
	/**
	 *
	 *Chat 
	 */
	function chat($parameters){ 
		
		     $return_array = array();
        $database = new medoo();
								
							
								
								$sendername = $parameters["sender_name"];
         $data['sender_id'] = $parameters["sender_id"];
         $data['receiver_id'] = $parameters["receiver_id"];
							 	$data['message'] = $parameters["message"];
									$data['message_type'] = $parameters["message_type"];
									$data['extension'] = $parameters["extension"];	
								 $data['time'] = utc_date();
									
										 $checkblockeduser = is_blocked($data['sender_id'],$data['receiver_id']);
										
										if($checkblockeduser != 0){
											
														$return_array = failure("User is blocked");
														
														$return_array['blocked_status'] = $checkblockeduser;
														return $return_array;
													
													die();
											
										}
									
									if(isset($_FILES['chatmedia']) && !empty($_FILES['chatmedia'])){
									
																		$target_path = UPLOADS_URL ."/chatmedia/";
																		$random = md5(uniqid());
																		$ext = explode('.', basename($_FILES['chatmedia']['name']));
																		$file_extension = end($ext);
																		$target_path = $target_path . $random . "." . $ext[count($ext) - 1];
													
																	if (move_uploaded_file($_FILES['chatmedia']['tmp_name'], $target_path)) {
																		
																									$data['chat_media'] = '/uploads/chatmedia/'. $random . "." . $ext[count($ext) - 1]; 
																									$return_array['media_success'] = "Media Added successfully.";
																									
																	}else{
																													$return_array['media_upload_fail']= "Error uploading media";
																	}
									}	
											
		if($parameters['group_id']){
			  $GID = $parameters['group_id'];
					$get_GroupMembers = "select `group_members` from `lv_chat_group` where `group_id` = $GID AND `group_status` = 1";
					$get_GroupMembers_Query = $database->query($get_GroupMembers)->fetchAll(PDO::FETCH_ASSOC);
					//echo "<pre>"; print_r($get_GroupMembers_Query);
			
		}
		
	else{			
							
        $last_chat_id = $database->insert("lv_chat",$data);
								
								//echo $database->last_query(); die;
									 if($last_chat_id) {
              ###### push notification ######
                $receiver_device_token = get_device_id($data['receiver_id']);
																
													//	echo $receiver_device_token['Users']['0']['device_token'];die;
                if($receiver_device_token['Users']['0']['device_token']!=""){
                    $msgg['flag'] = "10";
                    $msgg['chat_id'] = $last_chat_id;
                    $msgg['sender_id'] = $data['sender_id'];
																				$msgg['sender_name'] = $sendername;
                    $msgg['receiver_id'] = $data['receiver_id'];                 
                    $msgg['msg'] = $data['message'];
                    $msgg['date'] = utc_date();
                    $msgg['sticker'] = $data['sticker'];
                    sendFcmeNotification($msgg,$receiver_device_token['Users']['0']['device_token']);
                }
              ###### push notification ######
              $return_array = success("Message sent successfully");
              $data["chat_id"] = $last_chat_id;
              $return_array["data"] = $data;
        }else{
              $return_array = failure("Error in sending chat message");
              $return_array["chat_id"] = [];
        }
													
		}
		
			return $return_array;		
	}
	
	
	/**
 *
 * GET message of two users
 *
 */
    function get_chat_messages($parameters){
        $return_array = array();
        $database = new medoo();
        $user_id = $parameters["user_id"];
        $friend_id = $parameters["other_user_id"];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 20;
        $offset = ($page - 1) * $items_per_page;
								
        $limit = " limit " . $offset . "," . $items_per_page;
        $chatquery = "select CASE WHEN ( FIND_IN_SET('$user_id' , `is_deleted`) ) THEN 'true' ELSE 'false' end as is_deleted ,
CASE WHEN ( FIND_IN_SET('$user_id' , `is_read`) ) THEN 'true' ELSE 'false' end as is_read , c.* from lv_chat as c where '$user_id' in (sender_id,receiver_id) and '$friend_id' in (sender_id,receiver_id)  order by chat_id DESC $limit";
								
        $chats = $database->query($chatquery)->fetchAll(PDO::FETCH_ASSOC);
								
								
								$updatedeletestatus = "update `lv_chat` set `is_read` = if(find_in_set($user_id,is_read),is_read, CONCAT(is_read, ',', $user_id)) where  `receiver_id` = $user_id OR `sender_id` = $user_id" ;
								$result = $database->query($updatedeletestatus);

								
								
								
        if($chats) {
              $return_array = success("Success");
              $return_array["chat"] = $chats;              
        }else{
              $return_array = failure("Error");
              $return_array["chat"] = [];
        }
        return $return_array;
    }

/*
 *DELETE message
 *
 */

	function delete_chat_message($parameters){
								$return_array = array();
        $database = new medoo();
        //$user_id = $parameters["user_id"];
							 $chat_id = $parameters["chat_id"];
		
					//$updatedeletestatus = "update `lv_chat` set `is_deleted` = if(find_in_set($user_id,is_deleted),is_deleted, CONCAT(is_deleted, ',', $user_id)) where  `chat_id` = $chat_id";
					
										///$result = $database->query($updatedeletestatus);
										
					 $database->delete("lv_chat", ["chat_id" => $chat_id]);
						
					

			
							if( $database ){
											$return_array = success("Delete Message successfully");
									}
									else{
											$return_array = failure("Failed");
               }
						
						return $return_array;	
		
	}
				
	
	
	
	/**
 *
 * GET User chat list
 *
 */
    function get_recent_chats($parameters){
        $return_array = array();
        $database = new medoo();
        $user_id = $parameters["user_id"];

        $page = $parameters["page"];
        if($parameters["page"]==""){$page=1;}
        $items_per_page = 10;
        $offset = ($page - 1) * $items_per_page;
        $limit = " limit " . $offset . "," . $items_per_page;

         $chatquery = "select DISTINCT CASE WHEN main.sender_id = '$user_id' THEN main.receiver_id ELSE main.sender_id END user_id, (Select count(*) from lv_chat where (!FIND_IN_SET($user_id , is_read) OR  is_read = '0')  AND receiver_id=$user_id AND sender_id=main.sender_id) as unread_count, main.* FROM lv_chat main LEFT JOIN lv_chat earlier ON earlier.chat_id > main.chat_id AND ( earlier.receiver_id = main.receiver_id AND earlier.sender_id = main.sender_id OR earlier.receiver_id = main.sender_id AND earlier.sender_id = main.receiver_id ) WHERE (main.receiver_id = $user_id OR main.sender_id = $user_id) AND earlier.chat_id IS NULL ORDER BY main.chat_id DESC $limit"; 
        $chats = $database->query($chatquery)->fetchAll(PDO::FETCH_ASSOC);
        if($chats) {
              foreach ($chats as $k=>$chat) {
															$targetuser_id = ($chat['receiver_id'] != $user_id ? $chat['receiver_id'] : $chat['sender_id']  );
                $chats[$k]["UserData"] = get_user_data($targetuser_id);
                //$chats[$k]["UserData"]['is_friend'] = is_friend($user_id,$chat['user_id']);
                $chats[$k]["UserData"]['is_blocked'] = is_blocked($user_id,$targetuser_id);
														
                
              } 
              $return_array = success("Success");
              $return_array["chat"] = $chats;              
        }else{
              $return_array = failure("Error");
              $return_array["chat"] = [];
        }
        return $return_array;
    }			
				
				
	
	/*
	 *get_user_profile
	 *
	 */
	
	
	function get_user_profile($parameters){
				$return_array = array();
		 	$database = new medoo();
			
			$targetuser['user_id'] = $parameters['target_user_id'];
				$targetuser = $parameters['target_user_id'];
				$my_user_id = $parameters['my_user_id'];
			$return_array1['Userdata'] = get_user_data($parameters['target_user_id']);
			
			$result = $database->query("SELECT count(id) as is_following, (select count(id) FROM `lv_followers` where `follower_user_id` =$targetuser) as following_count,(select count(id) FROM `lv_followers` where `followed_user_id` =$targetuser) as followed_count FROM `lv_followers` where `follower_user_id` =$my_user_id and `followed_user_id` =$targetuser")->fetchAll(PDO::FETCH_ASSOC);			
			
											 $return_array1['Userdata']['Is_following'] = ($result['0']['is_following'] == 0 ? "false" : "true" );
												$return_array1['Userdata']['Followings_count'] = $result['0']['following_count'];
												$return_array1['Userdata']['Followers_count'] = $result['0']['followed_count'];
			 	       $return_array = success("Followed users list");
            $return_array["data"] = $return_array1;
			
			return $return_array;
		
		
	}
	
    
/***
 *
 *Update Student data use if student have university data like name and id 
 *
 **/

function save_external_share()
	{	
		 $database = new medoo();
       $return_array = array();
							$data['share_type'] = $_REQUEST['share_type'];
							$data['notify_id'] = $_REQUEST['notify_id'];
							$data['user_id'] = $_REQUEST['user_id'];
							$data['owner_id'] = $_REQUEST['owner_id'];
							$data['user_name'] = $_REQUEST['user_name'];
							$data['lecture_event_name'] = $_REQUEST['lecture_event_name'];
                            
                             if($data['share_type'] == "" || $data['notify_id'] == "" || $data['user_id'] == "" || $data['owner_id'] =="" || $data['user_name']=="" || $data['lecture_event_name'] == "")
                            {
                            $return_array = failure("Some parameters are missing.");
                            return $return_array;		
                            die;
                        }
                        
							$table_name = 	$data['share_type'] == "0" ? 'lv_quick_lecture' : 'lv_events'	;		
							$lecture_or_event = 	$data['share_type'] == "0" ? 'lecture' : 'event'	;		
                            
							$notif_msg = "Your ".$lecture_or_event." ".$data['lecture_event_name']." has been externally shared by ".$data['user_name'];
                            
                            //echo $table_name .' | '.$data['notify_id'].' | '. $data['user_id'] .' | '.$data['owner_id'] .' | '.$data['type'] .' | '.$data['user_name'] .' | '.$notif_msg;
                            //die;
							notify_user($data['owner_id'],$data['user_id'],$notif_msg,$data['notify_id'],"external_share",$table_name); // reciever_id, sender_id, msg, quick_lecture_id(optional)				
                           
                            $return_array = success("Data Saved successfully");
                            
                            $notified_user = get_user_data($data['owner_id']);
                            if($notified_user['device_token']!=""){
                                    $msgg['share_type'] = $data['share_type'];
                                    $msgg['notify_id'] = $data['notify_id'];
                                    $msgg['user_id'] = $data['user_id'];
                                    $msgg['owner_id'] = $data['owner_id'];
                                    $msgg['user_name'] = $data['user_name'];
                                    $msgg['lecture_event_name'] = $data['lecture_event_name'];
                            
                                    $msgg['flag'] = "7";
                                    $msgg['user_id'] = $notified_user['user_id'];
                                    $msgg['content_available'] = true;
                                    $msgg['msg'] = $notif_msg; 
                                    sendFcmeNotification($msgg,$notified_user['device_token']);
                            }
						return  $return_array;			
}
function mark_notification_read()
{
        $database = new medoo();
        $return_array = array();
        $notification_id = $_REQUEST['notification_id'];
        if($notification_id  == '' || $notification_id  == '0')
        {
             $return_array = failure("Invalid notification id.");
             return $return_array;
        }
        $query = "UPDATE `lv_notifications` set `is_viewed` = 'Y' where  `id` = '$notification_id'";   
        $database->myupdate($query) ;
        $return_array = success("Updated successfully");
        return $return_array;
    }

?>