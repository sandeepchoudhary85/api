<?php
ini_set('post_max_size', '50M');
ini_set('max_input_time', 500);
ini_set('upload_max_filesize', '30M');
ini_set('max_execution_time', 3000);
//date_default_timezone_set('UTC');




//define("GOOGLE_API_KEY", "AIzaSyDSQ0s9znEe5VCsKxdD-1duANDY-PvLtIY");
// push notification flags
//define('PUSH_FLAG_CHATROOM', 1);
//define('PUSH_FLAG_USER', 2);

$LectureVerbMainpath =  $_SERVER['DOCUMENT_ROOT'] . dirname($_SERVER['PHP_SELF'])."/";
$LectureVerbUploadurl =  $_SERVER['DOCUMENT_ROOT'] . dirname($_SERVER['PHP_SELF'])."/uploads"; // upload directory
$LectureVerbUploadurlmain =  $_SERVER['DOCUMENT_ROOT']."/lecture_verb_staging/app/uploads"; // upload directory


function CreateUploadsDirectoryStructure($LectureVerbUploadurlmain)
	{
		
			$year =  $LectureVerbUploadurlmain .'/ppt/'.date('Y');
			$month  = date('M');
			$date = date('d');

			if (!file_exists($year)) {
				mkdir($year, 0777, true);
			}

			if (!file_exists($year.'/'.$month)) {
				mkdir($year.'/'.$month, 0777, true);
			}

			if (!file_exists($year.'/'.$month.'/'.$date)) {
				mkdir($year.'/'.$month.'/'.$date, 0777, true);
			}


			return $year.'/'.$month.'/'.$date.'/';
						 
	}	



 // base url with slash

$LectureVerbUploadurlPPT =  $_SERVER['DOCUMENT_ROOT'] . dirname($_SERVER['PHP_SELF'])."/uploads/ppt/".CreateUploadsDirectoryStructure($LectureVerbUploadurl); // upload directory
//$LectureVerbUploadurlPPT = CreateUploadsDirectoryStructure($LectureVerbUploadurl); // upload directory
$LectureVerbUploadurlFORDOWNLOADFILES =  CreateUploadsDirectoryStructure($LectureVerbUploadurlmain); // upload directory
$LectureVerbNoimage =  $_SERVER['DOCUMENT_ROOT'] . dirname($_SERVER['PHP_SELF'])."/assets/img"; // upload directory 
$LectureVerbMainpathWithouslash =  $_SERVER['DOCUMENT_ROOT'] . dirname($_SERVER['PHP_SELF']).""; // base url with slash

define('BASE_URL', $LectureVerbMainpath);
define('UPLOADS_URL' , $LectureVerbUploadurl);
define('UPLOADS_URLPPT' , $LectureVerbUploadurlPPT);
define('LectureVerbUploadurlFORDOWNLOADFILES' , $LectureVerbUploadurlFORDOWNLOADFILES);

/******** zamzar Configuration *******/
define('BASE_URL_WITOUT_SLASH', $LectureVerbMainpathWithouslash);
define('APIKEY' , '4eb5f55b3e6a535a46e747443bc0a50b8a6092a1');
define('ZAMZARURL' , 'https://sandbox.zamzar.com');
define('MainURL' , 'http://103.43.152.211/lecture_verb_staging');
define('MainURLSUBDIR' , 'http://103.43.152.211/lecture_verb_staging/app');
/******** zamzar Configuration *******/

$LectureVerb = $_REQUEST['lectureverb'];

/*
*
*Check if users is exist
*
*/


 function user_existed( $email ){
    $database = new medoo();

      $select_email = "SELECT `email` FROM `lv_users` WHERE `email`='$email'"; 
      $result_select_email = $database->query($select_email)->fetchAll(PDO::FETCH_ASSOC);
    //print_r(count($result_select_email)); die;
    //echo $database->last_query(); die;
    if(count($result_select_email) == 1 ){ 
      return false;
    }else{
      return true;
    }
  }


/*
*
*get user id by email
*
*/

  
   function user_id_by_email( $email ){
    $database = new medoo();

      $select_email = "SELECT `user_id`,`email` FROM `lv_users` WHERE `email`='$email'"; 
      $result_select_email = $database->query($select_email)->fetchAll(PDO::FETCH_ASSOC);
      
      return $result_select_email['0']['user_id'];
    
  }



/*
*Get All Count of lectures
*
*/


function get_all_countsof_leacture($lectureID){
 $database = new medoo();
	
	$getallcount = "SELECT (SELECT count(*) from  `lv_comments` where `quick_lecture_id` = $lectureID) as 'comments_count', '0' as 'reposted_count',
(SELECT count(*) from  `lv_lecture_repost_status` where `quick_lecture_id` = $lectureID) as repost_lecture_count,
(SELECT count(*) from  `lv_likes` where `quick_lecture_id` = $lectureID) as likes_count ,
(SELECT count(*) from  `lv_favourite_list` where `quick_lecture_id` = $lectureID) as favourites_count";
	
$result_select_email = $database->query($getallcount)->fetchAll(PDO::FETCH_ASSOC);
	
	return $result_select_email['0'];


}
//get_all_countsof_leacture(20);

/*
*
*Failure responce
*
*/
  
  
  
    function failure($message){
      $response = array();
      $response["status"] = "Failure";
      $response["code"] = "400";
      $response["message"] = $message;
      return $response;
  }


/*
*
*Success Responce
*
*/

function success($message){
      $response = array();
      $response["status"] = "Success";
      $response["code"] = "200";
      $response["message"] = $message;
      return $response;
  }


/*
*
*Get device id
*
*/


  function get_all_users($user_id){
    $return_array = array();
    $database = new medoo();
    $get_all_users = "SELECT * from `lv_users`";
    $get_all_users = $database->query($get_all_users)->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($get_all_users)){
      $return_array = success("List of users");
      $return_array["Users"] = $get_all_users;
    }else{
      $return_array = failure("Error occurred, try after sometime...");
    }
    return $return_array;
  }





 
/*
*
*Get device id
*
*/


  function get_device_id($user_id){
    $return_array = array();
    $database = new medoo();
    $get_all_users = "SELECT * from `lv_users` where user_id =$user_id";
    $get_all_users = $database->query($get_all_users)->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($get_all_users)){
      $return_array = success("List of users");
      $return_array["Users"] = $get_all_users;
    }else{
      $return_array = failure("Error occurred, try after sometime...");
    }
    return $return_array;
  }

/*
*
*Get event and lecture Interest
*
*/
    
 
function get_lecture_orevent_interest($interest_id,$interest_type){
	    $database = new medoo();  
	    //$get_vategories = "SELECT * FROM `lv_lecture_or_event_interests` where interest_id =$interest_id and interest_type='$interest_type'"; 
      $get_vategories = "SELECT ei.*, (SELECT category FROM lv_categories WHERE id=ei.category_id) AS category_name FROM `lv_lecture_or_event_interests` ei where ei.interest_id =$interest_id and ei.interest_type='$interest_type'"; 
      
       $result_get_vategories = $database->query($get_vategories)->fetchAll(PDO::FETCH_ASSOC);
	     return $result_get_vategories;
} 
  
  //echo get_lecture_orevent_interest(18 ,1,'event');
  
/*
*
*Get User Interest
*
*/
  
  
function get_user_interest($userID){
	    $database = new medoo();  
	     $get_vategories = "SELECT ui.*, (SELECT category FROM lv_categories WHERE id=ui.category_id) AS category_name FROM `lv_users_interest` ui where ui.user_id ='$userID'"; 
          
	     $result_get_vategories = $database->query($get_vategories)->fetchAll(PDO::FETCH_ASSOC);
	     return $result_get_vategories;
}


/*
*
*Get User data by id
*
*/


  function get_user_data($userID){
     $database = new medoo();   
     $select_user = "SELECT `microphone`,`device_name`, `mac_address`, `signal_strength` ,`cover_pic`,`user_id`,`role_id`,`full_name`,`email`,`device_type`,`device_token`,`register_via`,`social_id`,`profile_pic`,`login_status`,`location`,`lat`,`lang`,`website`,`bio` FROM `lv_users` WHERE `user_id`='$userID'";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
     $result = $result[0];
      $result['user_interest'] = get_user_interest($userID);
      
      
      return $result;     
  }

  function get_userid_by_event_id($eventid){
     $database = new medoo();   
     $select_user = "SELECT user_id FROM lv_events WHERE event_id='$eventid'";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
     $result = $result[0]['user_id'];
     return $result;     
  }
  function get_eventid_by_user_id($userid){
     $database = new medoo();   
     $select_user = "SELECT event_id FROM lv_events WHERE user_id='$userid'";
     $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
     if(count($result)){
        $result = $result[0]['event_id'];
     }else{
        $result = "";
     }
     return $result;     
  }

  function check_is_reposted($userid,$lecture_id){
    $database = new medoo();   
    $select_user = "SELECT id FROM lv_lecture_repost_status WHERE user_id='$userid' and quick_lecture_id='$lecture_id'";
    $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
    if(count($result)){
      $result = true;
    }else{
      $result = false;
    }
    return $result;
  }



  function check_is_reposted_lecture_id($userid,$lecture_id){
    $database = new medoo();   
    $select_user = "SELECT id,quick_lecture_id FROM lv_lecture_repost_status WHERE user_id='$userid' and quick_lecture_id='$lecture_id'";
    $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
    //echo "<pre>"; print_r($result); die;
    if(count($result)){
      $result = $result['0']['reposted_id'];
    }else{
      $result = $result['0']['parent_lecture_user_id'];
    }
    return $result;
  }
  

/*
*
*Get username by id
*
*/

  function get_user_name_by_id($userID){
     $database = new medoo();   
     $select_user = "SELECT full_name FROM `lv_users` WHERE `user_id`='$userID'";
      $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
      return $result['0'];     
  }




/*
*
*Get Quick Lecture creator id
*
*/

  function get_quick_lecture_user_details($quick_lecture_id){
     $database = new medoo();   
     $select_user = "SELECT ql.quick_lecture_text , ql.user_id,u.full_name, u.device_token FROM `lv_quick_lecture` as ql INNER JOIN `lv_users` as u ON u.`user_id` = ql.`user_id` WHERE `quick_lecture_id`='$quick_lecture_id'";
      $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
      return $result['0'];     
  }




/*
*
*Get Even details
*
*/

  function get_event_user_details($event_id){
     $database = new medoo();   
     $select_user = "SELECT ql.lecture_title , ql.user_id,u.full_name, u.device_token FROM `lv_events` as ql INNER JOIN `lv_users` as u ON u.`user_id` = ql.`user_id` WHERE `event_id`='$event_id'";
      $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
      return $result['0'];     
  }






/*
*
*Utc date time
*
*/

  function utc_date($date = ""){
      //date_default_timezone_set('UTC');
      //if($date){
      //    $utcdate = $date;
      //} else {
      //    $utcdate = date('Y-m-d H:i:s');
      //}
      
     $utcdate = date('Y-m-d H:i:s');  
      $the_date = strtotime($utcdate);
	(date_default_timezone_set("UTC"));
	$date = (date("Y-m-d H:i:s", $the_date));
      
      
      return $date;
  }

/*
*
*
*INsert date in notification table
*
*/

  function notify_user($notif_receiver_id, $notif_sender_id, $notif_msg, $quick_lecture_id,$actionn, $notify_id_table){ // reciever_id, sender_id, msg, wish_id(optional)

      $database = new medoo();
      $data["sender_id"] = $notif_sender_id;
      $data["receiver_id"] = $notif_receiver_id;
      $data["notify_id"] = ($quick_lecture_id ? $quick_lecture_id : 0);
      $data["notify_id_table"] = $notify_id_table;
      $data["message"] = $notif_msg;
      $data["type"] = ($actionn ? $actionn : '');
      $data["date_time"] = utc_date();
      $updatedate = utc_date();
	  
       $checkrecodralready = "SELECT * FROM `lv_notifications` where `sender_id` = '$notif_sender_id' AND `receiver_id` = '$notif_receiver_id' AND `notify_id` = '$quick_lecture_id' AND `notify_id_table` = '$notify_id_table' AND `message` = '$notif_msg' AND `type` = '$actionn'"; 
        $checkrecodralreadyresult = $database->query($checkrecodralready)->fetchAll(PDO::FETCH_ASSOC);
        if(count($checkrecodralreadyresult) == 0)
        {
            $last_user_id = $database->insert("lv_notifications",$data);
        }
    else{
             		$updateuserinfo = "update `lv_notifications` set `date_time` = '$updatedate' where `sender_id` = '$notif_sender_id' AND `receiver_id` = '$notif_receiver_id' AND `notify_id` = '$quick_lecture_id' AND `notify_id_table` = '$notify_id_table' AND `message` = '$notif_msg' AND `type` = '$actionn'";
                    $result = $database->query($updateuserinfo);
        }
	  //echo $database->last_query(); die;
	  
	  
  }





/*
*
*Check Account is verified or not 
*
*/
  
    function CheckAccountVerification($email){ 
      
     $database = new medoo();
     if($email)
     {
            $select_user = "SELECT status FROM `lv_users` WHERE `email`='$email'";
            $result = $database->query($select_user)->fetchAll(PDO::FETCH_ASSOC);
            //echo $database->last_query(); die;
            
            //print_r($result); die;
             if($result['0']['status'] == 0)
             {
                return false;
             }
            else
            {
              return true;
            }
     }
     
     else {
  
        return true;
      
     }
     // return $utcdate;
  }



/*
*
*Genrate rendome string 
*
*/

  
  function generateRandomString($length = 4) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/*
*
*Check user is blocked
*
*/


  function is_blocked($user_id, $blocked_user_id){
      $database = new medoo();  
      $is_blocked = $database->count("lv_blocked_users",["AND" => ["user_id" => $user_id,"blocked_user_id" => $blocked_user_id]]);
      if ($is_blocked == 1) { 
          $st = "1"; // 1 - blocked_user_id is blocked by user_id
      } else {
          $is_blocked_reverse = $database->count("lv_blocked_users",["AND" => ["user_id" => $blocked_user_id,"blocked_user_id" => $user_id]]);
          if ($is_blocked_reverse == 1) {
             $st = "2"; // 2 - user_id is blocked by blocked_user_id
          } else { 
            $st = "0"; // 0 - blocked_user_id is not blocked by user_id
          }
      }
     return $st;
  }


/*
*
*Check user is Liked lecture
*
*/

  function is_liked($quick_lecture_id, $user_id){
      $database = new medoo();  
      $is_liked = $database->count("lv_likes",["AND" => ["quick_lecture_id" => $quick_lecture_id,"user_id" => $user_id,"is_liked" => '1']]);        
      if ($is_liked>0) { $st = 1; } else { $st = 0; }
      return $st;
  }


/*
*
*Check user is favourite lecture
*
*/

  function is_favourite($quick_lecture_id, $user_id){
      $database = new medoo();  
      $is_liked = $database->count("lv_favourite_list",["AND" => ["quick_lecture_id" => $quick_lecture_id,"user_id" => $user_id,"is_favourite" => '1']]);        
      if ($is_liked>0) { $st = 1; } else { $st = 0; }
      return $st;
  }

//echo favourite(205,21);
/*
*
*Check user is intested in event or not
*
*/

  function check_event_attend_and_interest($user_id , $event_id){
      $database = new medoo();  
     $select_user_interst = "SELECT * FROM `lv_event_attend_and_interest` WHERE `event_id`='$event_id' AND `user_id` = '$user_id'";  
     $result = $database->query($select_user_interst)->fetchAll(PDO::FETCH_ASSOC);
	  
      return ($result ? $result['0'] : NULL);
  }

  
  /*
*
*Check Lecture user like comment and reposted
*
*/

  function get_lecture_user_like_comment_reposted($lecture_id){
      $database = new medoo();  
     $select_user_interst = "Select c.`user_id` , u.device_token from `lv_comments` as c join `lv_users` u ON u.user_id = c.user_id  where c.`quick_lecture_id` = $lecture_id Group by c.`user_id`
UNION
Select r.`user_id`, u1.device_token from `lv_lecture_repost_status` as r join `lv_users` u1 ON u1.user_id = r.user_id   where r.`quick_lecture_id` = $lecture_id Group by `user_id`
UNION
Select l.`user_id`, u2.device_token from `lv_likes` as l join `lv_users` u2 ON u2.user_id = l.user_id   where l.`quick_lecture_id` = $lecture_id Group by `user_id`";  
     $result = $database->query($select_user_interst)->fetchAll(PDO::FETCH_ASSOC);
	  
      //return ($result ? $result['0'] : NULL);
      return $result['0'];
  }
  
  
  


/*
*
*Check user is Invited to event
*
*/

  function invited($user_id , $event_id){
      $database = new medoo();  
      $is_liked = $database->count("lv_event_invitation",["AND" => ["receiver_id" => $user_id,"event_id" => $event_id]]);        
      if ($is_liked>0) { $st = 1; } else { $st = 0; }
      return $st;
  }



/*
*
*Email Function
*
*/
  

  //PHP MAIL FUNCTION
function mymail($to, $subject, $msg)
{
  //$t = "sandeep.kumar@amebasoftwares.com,sandeepchoudhary85@gmail.com";
  require("config/smtpphpmailer/PHPMailerAutoload.php");
  $mail = new PHPMailer();
  $mail->IsSMTP();
  $mail->SMTPDebug = 0;
  $mail->SMTPAuth = 'login';
  $mail->SMTPSecure = 'ssl';
  $mail->Host = 'smtp.gmail.com';
  $mail->Port = 465;
  $mail->Username = 'amebasoftwares123@gmail.com';
  //$mail->Username = 'recovery@wish-drop.com';
  $mail->Password = 'Ameba[2016]';
 // $mail->Password = 'wishdroprecovery';
  $mail->SetFrom('recovery@winestiock.com', 'LectureVerb App');
  $mail->Subject = $subject;
  $mail->Body = $msg;
  $mail->IsHTML(true);
  $mail->AddAddress($to);
  if($mail->Send()){
    $response = 1;
  } else {
    $response = 0;
  }
  return $response;
}



//**** FCM Pushnotification***

function sendFcmeNotification($data,$target){
	//echo $target;
     //echo "<pre>"; print_r($data); die;
       //FCM api URL
       $url = 'https://fcm.googleapis.com/fcm/send';
       //api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
       $server_key = 'AIzaSyBPQamurUEC8rwvV8eWmtk4V1lXcI6QCwI';
             
       $fields = array();
       $fields['data'] = $data;
       $fields['priority'] = "high";
        //$fields['content_available'] = true;
       $fields['data']['title'] = "LectureVerb"; 
       $fields['data']['body'] = $data; 
       $fields['data']['sound'] = "default";
       $fields['data']['content_available'] = true;          
       if(is_array($target)){
         $fields['registration_ids'] = $target;
       }else{
         $fields['to'] = $target;
       }
       //header with content_type api key
       $headers = array(
         'Content-Type:application/json',
         'Authorization:key='.$server_key
       );
             
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
       $result = curl_exec($ch);
       if ($result === FALSE) {
         die('FCM Send Error: ' . curl_error($ch));
       }
       curl_close($ch);
      // echo $result;
       return $result;
   }






?>
