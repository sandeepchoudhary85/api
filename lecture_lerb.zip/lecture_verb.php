<?php

  //die("testsafd");
 //ini_set('display_errors', 1);
 //ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);
 error_reporting('0');
  header('Content-type: application/json');
 header('Content-type: text/html; charset=utf-8');
require 'config/medoo.php';
require 'config/global_function.php';
require 'lecture_verb_functions.php';


require 'zamzar/uploadfile.php';
//require 'zamzar/download_files.php';
require 'zamzar/zamzar.php';

//print_r($_FILES); die;

/**
 *
 *Get User Role Signup
 *
 */
if($LectureVerb == "get_user_role"){
	
	$response = array();
	$parameters = array();
	$response = get_user_role($_REQUEST); 
	echo json_encode($response);
}


/**
 *
 *Registration Signup
 *
 */
if($LectureVerb == "signup"){
	
	$response = array();
	$parameters = array();
	$response = signup($_REQUEST); 
	echo json_encode($response);
}

/**
 *
 *Get all users
 *
 */
if($LectureVerb == "get_all_users"){
	
	$response = array();
	$parameters = array();
	$response = get_all_users($_REQUEST); 
	echo json_encode($response);
}


/*
*
*
* Logout user
*
*
*/

if($LectureVerb == "logout"){
  	$response = array();
  	$parameters = array();
    $count = count($_REQUEST);
    if( isset( $_REQUEST["user_id"] ) && isset( $_REQUEST["user_id"] ))
	{
  	  $response = logout($_REQUEST);
    }else{
      $response = failure("Missing Parametres");
    }
	  echo json_encode($response);
}



/**
 *
 *manual LOGIN
 */

if($LectureVerb == "login"){
	$response = array();
	if( isset( $_REQUEST["email"] ) && isset( $_REQUEST["password"] )){
		$response = login($_REQUEST);
	}else{
		$response = failure('Missing key values');
	}
	echo json_encode($response);
}



/**
 *
 *Social LOGIN
 */

if($LectureVerb == "social_login"){
	$response = array();
	$parameters = array();
	$response = social_login($_REQUEST); 
	echo json_encode($response);
}




/**
 *
 *Check Email verification
 *
 */

	if($LectureVerb == "emailverification"){
	$response = array();
	if( isset( $_REQUEST["email"] ) && isset( $_REQUEST["user_id"] ) && isset( $_REQUEST["verification_code"] )){
		$response = emailverification($_REQUEST);
	}else{
		$response = failure('Missing key values');
	}
	echo json_encode($response);
}
	
	
	/**
 *
 *Resend Email verification code
 *
 */

	if($LectureVerb == "resendverificationcode"){
	$response = array();
	if( isset($_REQUEST["email"] )){
		    $email = $_REQUEST["email"]; 
	    	//$str = 'Q1H*';
			$shuffled = generateRandomString();
			$response = sendverificationemail($email , $shuffled);
	}else{
		$response = failure('Missing key values');
	}
	echo json_encode($response);
}
	
	
/***
 *
 *FORGOT PASSWORD
 **/
if($LectureVerb == "forgot_password"){ 
	$response = array();
	if( isset( $_REQUEST["email"] )){
		$response = forgot_password($_REQUEST["email"]);
	}else{
		$response = failure('Missing key values');
	}
	echo json_encode($response);
}
	
	
/***
 *
 *Get Wine List
 *
 **/

if($LectureVerb == 'get_wine_list')
{
	
		    $response = array();
		
				 	$response = get_wine_list($_REQUEST);

		    echo json_encode($response);
	
}



/***
 *
 *Update Student data
 *
 **/

if($LectureVerb == 'submit_student_data')
{
	
		    $response = array();
		
			$response = submit_student_data($_REQUEST);

		    echo json_encode($response);
	
}



/***
 *
 *Update Device Token
 *
 **/

if($LectureVerb == 'update_device_token')
{
	
		    $response = array();		
			$response = update_device_token($_REQUEST);
		    echo json_encode($response);
	
}



/***
 *
 *Update User Profile
 *
 **/

if($LectureVerb == 'update_profile')
{
	
		    $response = array();		
			$response = update_profile($_REQUEST);
		    echo json_encode($response);
	
}



/***
 *
 *Update User Profile image
 *
 **/

if($LectureVerb == 'update_profile_image')
{
	
		    $response = array();			
			$response = update_profile_image($_REQUEST);
		    echo json_encode($response);
	
}




/***
 *
 *Update User Cover image
 *
 **/

if($LectureVerb == 'update_profile_cover_image')
{
	
		    $response = array();
			$response = update_profile_cover_image($_REQUEST);
		    echo json_encode($response);
	
}



/***
 *
 *Update User Notification Setting
 *
 **/

if($LectureVerb == 'update_user_notification')
{
	
		    $response = array();		
		  	$response = update_user_notification($_REQUEST);
		    echo json_encode($response);
	
}


/**
 *
 *Insert User Ash Tags
 *
 **/

 
 if($LectureVerb == 'add_user_ash_tags')
{
	
		    $response = array();		
			  $response = add_user_ash_tags($_REQUEST);
		    echo json_encode($response);
	
}



/**
 *
 *Get all User Ash Tags
 *
 **/

 
 if($LectureVerb == 'get_ash_tags')
{
	
		    $response = array();		
			  $response = get_ash_tags($_REQUEST);
		    echo json_encode($response);
	
}



/*
 *
 * iNSERT Add quick lecture
 *
 */

 if($LectureVerb  == 'add_quick_lecture')
 {
		$response = array();
		$response = add_quick_lecture($_REQUEST);
		echo json_encode($response);
	
	
 }
 

/*
 *
 * iNSERT update_quick_lecture quick lecture
 *
 */

 if($LectureVerb  == 'update_quick_lecture')
 {
		$response = array();
		$response = update_quick_lecture($_REQUEST);
		echo json_encode($response);
	
	
 }


/*
 *
 * Add quick lecture update_quick_lecture_thumbnail
 *
 */

 if($LectureVerb  == 'update_quick_lecture_thumbnail')
 {
		$response = array();
		$response = update_quick_lecture_thumbnail($_REQUEST);
		echo json_encode($response);
	
	
 }
 


/*
*
* Update Lecture Event
*/


 if($LectureVerb  == 'update_lecture_event')
 {
		$response = array();
		$response = update_lecture_event($_REQUEST);
	 //echo "<pre>"; print_r($response);
		echo json_encode($response);
	
	
 }


/*
 *
 * Get quick lecture 
 *
 */

 if($LectureVerb  == 'get_posted_lectures')
 {
    $response = array();
    $response = get_posted_lectures($_REQUEST);
    echo json_encode($response);
    
 }

/*
 *
 * Get my posted lectures lecture 
 *
 */

 if($LectureVerb  == 'get_my_posted_lectures')
 {
    $response = array();
    $response = get_my_posted_lectures($_REQUEST);
    echo json_encode($response);
    
 }

/*
 *
 * Like Unlike 
 *
 */

 if($LectureVerb =='like_unlike_lecture'){
        $response = array();
        if(isset($_REQUEST['quick_lecture_id'])) {
          $response=like_unlike_lecture($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }



/*
 *
 * Add Lecture remove to favourite list
 *
 */

 if($LectureVerb =='add_remove_to_favourite_list'){
        $response = array();
        if(isset($_REQUEST['quick_lecture_id'])) {
          $response=add_remove_to_favourite_list($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }

/*
 *
 * GET Lecture favourite list
 *
 */


 if($LectureVerb =='get_favourite_lectures'){
        $response = array();
        if(isset($_REQUEST['user_id'])) {
          $response=get_favourite_lectures($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }


/*
 *
 * GET Lecture Liked list
 *
 */

 if($LectureVerb =='get_liked_lectures'){
        $response = array();
        if(isset($_REQUEST['user_id'])) {
          $response=get_liked_lectures($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }


/*
 *
 * Add Lecture to play list 
 *
 */

 if($LectureVerb  == 'add_lecture_to_recent_played_list')
 {
		$response = array();
		$response = add_lecture_to_recent_played_list($_REQUEST);
		echo json_encode($response);
	
 }	

/*
 *
 * GET Recent Played lectures
 *
 */

 if($LectureVerb =='get_recent_played_lectures'){
        $response = array();
        if(isset($_REQUEST['user_id'])) {
          $response=get_recent_played_lectures($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }

/*
 *
 * Create lecture events 
 * OR upcoming lecture
 *
 */



 if($LectureVerb =='create_lecture_event'){
        $response = array();
        if(isset($_REQUEST['user_id'])) {
          $response=create_lecture_event($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }


/*
 *
 * Get lecture events by user id
 * OR upcoming lecture
 *
 */



 if($LectureVerb =='get_lecture_event'){
        $response = array();
        //if(isset($_REQUEST['user_id'])) {
          $response=get_lecture_event($_REQUEST);
       // }else{
        //  $response=failure("Missing key values");
       // }
        echo json_encode($response);
    }


/*
 *
 * Get lecture events by event id
 * OR upcoming lecture
 *
 */



 if($LectureVerb =='get_single_lecture_event'){
        $response = array();
        if(isset($_REQUEST['event_id'])) {
          $response=get_single_lecture_event($_REQUEST);
        }else{
          $response=failure("Missing key values");
        }
        echo json_encode($response);
    }


/*
 *
 * 
 * Comment on lecture
 *
 */


if($LectureVerb == "lecture_write_comment"){
  $response = array();
  if (isset($_REQUEST["quick_lecture_id"]) && !empty($_REQUEST["quick_lecture_id"])) {
    $response = lecture_write_comment($_REQUEST);
  }else {
    $response = failure("quick lecture id is mandatory.");
  }
  echo json_encode($response);
}



/*
 *
 * 
 * Comment on lecture
 *
 */


if($LectureVerb == "write_comment_reply"){
  $response = array();
  if (isset($_REQUEST["comment_id"]) && !empty($_REQUEST["comment_id"])) {
    $response = write_comment_reply($_REQUEST);
  }else {
    $response = failure("Comment id is mandatory.");
  }
 
  echo json_encode($response);
}


/*
 *
 * 
 * Get Comments list
 *
 */


if($LectureVerb == "comments_list"){
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = comments_list($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
}




/*
 *
 * 
 * Get Reply on Comments
 *
 */


if($LectureVerb == "reply_comments_list"){
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = reply_comments_list($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
}




/*
 *
 * 
 * Block unblock user
 *
 */


if($LectureVerb == "block_unblock_user"){
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = block_unblock_user($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
}





/*
 *
 * 
 * Get Reply on Comments
 *
 */


if($LectureVerb == "get_block_users"){
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_block_users($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
}




/*
 *
 * 
 * Get Reply on Comments
 *
 */


if($LectureVerb == "get_notifications"){
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_notifications($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
}



/***
 *
 *Update Device Token update_device_token
 *
 **/

if($LectureVerb == 'update_device_details')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = update_device_details($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/***
 *
 *Search by name 
 *
 **/

if($LectureVerb == 'search_user')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = search_user($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/***
 *
 *Search by name 
 *
 **/

if($LectureVerb == 'get_single_user')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_single_user($_REQUEST);
  }else {
    $response = failure("User id is mandatory.");
  }
 
  echo json_encode($response);
	
}


/***
 *
 *Search by name 
 *
 **/

if($LectureVerb == 'get_all_hash_tags')
{	
  $response = array();
  $response = get_all_hash_tags($_REQUEST); 
  echo json_encode($response);
}



/***
 *
 *Search Near by co host
 *
 **/

if($LectureVerb == 'get_nearby_co_hosts')
{
	
  $response = array();
  if (isset($_REQUEST["latitude"]) && !empty($_REQUEST["longitude"])) {
    $response = get_nearby_co_hosts($_REQUEST);
  }else {
    $response = failure("Lat long is mandatory.");
  }
 
  echo json_encode($response);
	
}




/***
 *
 *Event Attent and Intrest
 *
 **/

if($LectureVerb == 'event_attend_and_interest')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["event_id"])) {
    $response = event_attend_and_interest($_REQUEST);
  }else {
    $response = failure("User and event id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/***
 *
 *Send Event invitation
 *
 **/

if($LectureVerb == 'send_event_invitation')
{
	
  $response = array();
  if (isset($_REQUEST["sender_id"]) && !empty($_REQUEST["event_id"])) {
    $response = send_event_invitation($_REQUEST);
  }else {
    $response = failure("sender_id and event id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/***
 *
 *GEt Event invitation
 *
 **/

if($LectureVerb == 'get_event_invitation')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_event_invitation($_REQUEST);
  }else {
    $response = failure("user id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/***
 *
 *Get Event Co Hosts 
 *
 **/

if($LectureVerb == 'get_my_hosting_list')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_my_hosting_list($_REQUEST);
  }else {
    $response = failure("user id is mandatory.");
  }
 
  echo json_encode($response);
	
}



/**
 *
 * GET Search Lecture events
 *
 */

if($LectureVerb == 'search_lecture_event')
{
	
  $response = array();
  if (isset($_REQUEST["keyword"]) && !empty($_REQUEST["keyword"])) {
    $response = search_lecture_event($_REQUEST);
  }else {
    $response = failure("keyword is mandatory.");
  }
 
  echo json_encode($response);
	
}


/**
 *
 * Share lecture and events
 *
 */

if($LectureVerb == 'share')
{
	
  $response = array();
  if (isset($_REQUEST["shared_id"]) && !empty($_REQUEST["user_id"])) {
    $response = share($_REQUEST);
  }else {
    $response = failure("share id and user id is mandatory.");
  }
 
  echo json_encode($response);
	
}

/**
 *
 * Get Share lecture and events
 *
 */

if($LectureVerb == 'get_share_list')
{
	
  $response = array();
  if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["user_id"])) {
    $response = get_share_list($_REQUEST);
  }else {
    $response = failure("share id and user id is mandatory.");
  }
 
  echo json_encode($response);
	
}


/**
 *
 * Get cat and sub cat
 *
 */

if($LectureVerb == 'get_categories')
{	

  $response = array();
    $response = get_categories($_REQUEST);  
  echo json_encode($response);
	
}

/**
 *
 * save users interest
 *
 */

if($LectureVerb == 'save_users_interest')
{	
    $response = array();
    
				if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["category_id"])) {
    $response = save_users_interest($_REQUEST);
  }else {
    $response = failure("user id and category id is mandatory.");
  }
    echo json_encode($response);
	
}


/**
 *
 * save lecture and event interest
 *
 */

if($LectureVerb == 'save_lecture_or_event_interest')
{	
    $response = array();
    
				if (isset($_REQUEST["user_id"]) && !empty($_REQUEST["category_id"])) {
    $response = save_lecture_or_event_interest($_REQUEST);
  }else {
    $response = failure("user id and category id is mandatory.");
  }
    echo json_encode($response);
	
}




/***** Test****/

 if($LectureVerb  == 'gotodownloadfile11')
 { 
		$response = array();
		$response = checkstatus(1366608 , 1 , 20);
		echo json_encode($response);
	
	
 }


/*
 *
 * Get suggested lecture 
 *
 */

 if($LectureVerb  == 'get_suggested_lectures')
 {
    $response = array();
    $response = get_suggested_lectures($_REQUEST);
    echo json_encode($response);
    
 }

/*
 *
 * REPOST A LECTURE
 *
 */

 if($LectureVerb  == 'repost_lecture')
 {
    $response = array();
    $response = repost_lecture($_REQUEST);
    echo json_encode($response);
    
 }
 
 /*
 *
 * UNREPOST A LECTURE
 *
 */

 if($LectureVerb  == 'unrepost_lecture')
 { 
    $response = array();
    $response = unrepost_lecture($_REQUEST);
    echo json_encode($response);
    
 }
 
 
 

/*
 *
 * List of users who reposted a lecture
 *
 */

 if($LectureVerb  == 'repost_lecture_users_list')
 {
    $response = array();
    $response = repost_lecture_users_list($_REQUEST);
    echo json_encode($response);
    
 }
/*
 *
 * Follow a user
 *
 */

 if($LectureVerb  == 'follow_user')
 {
    $response = array();
    $response = follow_user($_REQUEST);
    echo json_encode($response);
    
 }
 if($LectureVerb  == 'get_my_followers')
 {
    $response = array();
    $response = get_my_followers($_REQUEST);
    echo json_encode($response);
    
 }
 if($LectureVerb  == 'get_my_followings')
 {
    $response = array();
    $response = get_my_followings($_REQUEST);
    echo json_encode($response);
    
 }
 if($LectureVerb  == 'people_you_may_know')
 {
    $response = array();
    $response = people_you_may_know($_REQUEST);
    echo json_encode($response);
    
 }

 if($LectureVerb  == 'chat')
 { 
    $response = array();
    $response = chat($_REQUEST);
    echo json_encode($response);
    
 }
	
	 if($LectureVerb  == 'delete_chat_message')
 { 
    $response = array();
    $response = delete_chat_message($_REQUEST);
    echo json_encode($response);
    
 }

	 if($LectureVerb  == 'get_chat_messages')
 { 
    $response = array();
    $response = get_chat_messages($_REQUEST);
    echo json_encode($response);
    
 }
	

 if($LectureVerb  == 'get_user_profile')
 {
    $response = array();
    $response = get_user_profile($_REQUEST);
    echo json_encode($response);
    
 }

	
	 if($LectureVerb  == 'get_recent_chats')
 {
    $response = array();
    $response = get_recent_chats($_REQUEST);
    echo json_encode($response);
    
 }


/***
 *
 *add an external share
 *
 **/

if($LectureVerb == 'save_external_share')
{
		    $response = array();
			$response = save_external_share($_REQUEST);
		    echo json_encode($response);
}

/***
*mar the notification as read in the lv_notification_table
**/
if($LectureVerb == 'mark_notification_read')
{
		    $response = array();
			$response = mark_notification_read($_REQUEST);
		    echo json_encode($response);
}


	
		 if($LectureVerb  == 'demonotification')
						{
									$msgg['flag'] = "3";
									$msgg['user_id'] = 1;
									$msgg['quick_lecture_id'] = 2;
									$mmm='demo demo';
									$ta = 'cqCE5eI9tO0:APA91bFb4iBsyA9CNo_nva-ADihqu9cOFjzmK7jNjFrg0wNP4z9OnR7lN7I0dil7tTMvn0KsDNRAqa2TiKDbFXTj78u3hyH47WtVzOctoThVILh05Tcc_2xRn-Oh2rkgOeXmpSAs1bPD';
									$msgg['msg'] = "Your Lecture (".$mmm.") is action by  sandeep"; 
									sendFcmeNotification($msgg,$ta);
									
						}



?>
